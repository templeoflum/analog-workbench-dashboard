from pathlib import Path
import struct,json,numpy as np,hashlib
p=Path(__file__).resolve().parent;b=(p/'TransientAnalysis.dat').read_bytes()
assert hashlib.sha256(b).hexdigest()=='f15456cc811fef4269e72278b7bb945bca1bc7ff7d3ebea2edb893790a24be4b', 'Unsupported or altered fixture'
def u32(pos):return struct.unpack_from('<I',b,pos)[0]
def metadata(name):return u32(b.index(name.encode()+b'\0')+len(name)+1)
assert metadata('NumberofAnalogColumns')==28 and metadata('NumberofAnalogRows')==1009
pos=b.index(b'SweepMode\0')+len(b'SweepMode\0')+4;n=u32(pos);pos+=4;aliases=[]
for i in range(n):
 typ,width,count=struct.unpack_from('<III',b,pos);pos+=12;assert typ==1 and width==8;names=[]
 for j in range(count):
  length=u32(pos);pos+=4;assert b[pos+length]==0;names.append(b[pos:pos+length].decode('ascii'));pos+=length+1
 aliases.append(names)
assert b[pos:pos+8]==b'\0'*8;pos+=8;offsets=struct.unpack_from('<28Q',b,pos);cols=[]
assert offsets[0]==pos+28*8
for i,off in enumerate(offsets):
 reserved,count,hi,lo=struct.unpack_from('<QQdd',b,off);assert reserved==0 and count==1009;end=off+32+count*8;assert end<=len(b)
 if i<27:assert end==offsets[i+1]
 values=np.frombuffer(b,dtype='<f8',count=count,offset=off+32).copy();assert np.isfinite(values).all();assert abs(values.max()-hi)<1e-10 and abs(values.min()-lo)<1e-10;cols.append(values)
def get(name):return cols[next(i for i,a in enumerate(aliases) if name in a)]
t=get('Time');assert t[0]==0 and abs(t[-1]-1e-7)<1e-18 and np.all(np.diff(t)>0)
assert np.max(abs(get('V(VIN)')-np.sin(2*np.pi*50e6*t)))<1e-12
for name,value in [('V(VCC)',15),('V(VEE)',-15),('V(0)',0),('V(Vref)',0)]:assert np.max(abs(get(name)-value))<1e-14
out=get('V(Vout)');minus=get('V(N02940)')
for actual,expected in [(get('I(R1)'),(minus-out)/2000),(get('I(R2)'),-minus/2000),(get('I(R4)'),out/1000)]:assert np.max(abs(actual-expected))<1e-12
assert abs(out[0]-.0084)<=.00005
np.savetxt(p/'manufacturer.csv',np.column_stack((t,get('V(VIN)'),out)),delimiter=',',header='time_s,input_V,output_V',comments='')
record=dict(sha256=hashlib.sha256(b).hexdigest(),rows=1009,columns=28,aliases=aliases,blockOffsets=offsets,uninterpretedTrailerBytes=len(b)-(offsets[-1]+32+1009*8),checksPassed=True,scope='Fixture-specific inferred decoder; structural and independent circuit invariants passed, not a general certified PSpice parser')
(p/'decoder-validation.json').write_text(json.dumps(record,indent=2));print('Decoded and checked 28 columns / 1009 samples')
