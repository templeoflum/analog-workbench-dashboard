from pathlib import Path
from run_cadet import circuit
import json,subprocess,math,concurrent.futures
ROOT=Path(__file__).resolve().parent
sources=json.loads((ROOT/'sources.json').read_text())['sources']
def run(args):
 mode,gain,source=args;name=f"{mode}-{gain}-{source['id']}";d=ROOT/name;d.mkdir(exist_ok=True)
 s=circuit(gain=gain,offset=.6,mode=mode,load=100000,tight=True).split('.control')[0].replace('.include ti/','.include ../ti/')
 s='\n'.join(l for l in s.splitlines() if not l.startswith('.options'))
 s+='\n.options klu method=gear gmin=1e-16 reltol=1e-6 abstol=1e-12 vntol=1e-9\n'
 old='VA source_a 0 DC 0 AC 1 PULSE(0 .2 100n 1n 1n 200n 1u)';assert old in s
 pwl='PWL('+ ' '.join(f'{i*.25e-9:.12g} {v:.17g}' for i,v in enumerate(source['input']))+')'
 s=s.replace(old,'VA source_a 0 '+pwl)
 s+='\n.control\nset wr_singlescale\nset wr_vecnames\nset numdgt=17\ntran .003125n 1u 0 .003125n\nwrdata tran.txt v(source_a) v(output)\nquit\n.endc\n.end\n';(d/'circuit.cir').write_text(s)
 r=subprocess.run(['ngspice','-n','-D','ngbehavior=ps','-b','circuit.cir'],cwd=d,capture_output=True,text=True,timeout=120);log=r.stdout+r.stderr;(d/'run.log').write_text(log)
 rows=[[float(v) for v in l.split()] for l in (d/'tran.txt').read_text().splitlines()[1:]] if (d/'tran.txt').exists() else []
 ok=r.returncode==0 and bool(rows) and not any(t in log.lower() for t in ['error','aborted','timestep too small']) and all(math.isfinite(v) for row in rows for v in row) and abs(rows[-1][0]-1e-6)<1e-17
 rec=dict(mode=mode,gain=gain,source=source['id'],completed=ok,rows=len(rows));(d/'record.json').write_text(json.dumps(rec,indent=2));print(name,ok,flush=True);return rec
if __name__=='__main__':
 jobs=[(m,g,s) for m in ['offset_input','offset_thru'] for g in [0,.5,1] for s in sources]
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,jobs))
 (ROOT/'records.json').write_text(json.dumps(results,indent=2))
 if not all(r['completed'] for r in results):raise SystemExit(1)
