import fs from 'node:fs';import assert from 'node:assert/strict';
import {SignalProcessor} from './runtime.mjs';import {diagnosticInput,sources,compareTrace} from './diagnostic-source.mjs';
const root=new URL('.',import.meta.url),model=JSON.parse(fs.readFileSync(new URL('runtime-model.json',root)));let sourceChecks=0;
for(const s of sources){const a=diagnosticInput(s.id);assert.equal(a.length,4001);assert.deepEqual(a,diagnosticInput(s.id));for(let i=0;i<a.length;i++){assert(Number.isFinite(a[i])&&a[i]>=0&&a[i]<=.2);if(i)assert(Math.abs(a[i]-a[i-1])<=.005+1e-14);}sourceChecks++;}
const close=(a,b)=>assert(Math.abs(a-b)<1e-14);
for(const [id,t,v] of [['flat',500,.1],['staircase',195,.025],['staircase',400,.1],['staircase',1000,.2],['ramp',450,.2],['ramp',800,0],['pulse',205,.08],['pulse',600,.16],['pulse',610,0],['sine1',250,.18],['sine1',750,.02],['sine5',50,.18],['sine5',150,.02]]){close(diagnosticInput(id)[t*4],v);sourceChecks++;}
assert.throws(()=>diagnosticInput('unknown'));sourceChecks++;
const zero=new Float64Array(4001);assert(compareTrace(zero,zero).passed);assert(!compareTrace(new Float64Array(4001).fill(.000101),zero).passed);const spike=zero.slice();spike[99]=.001001;assert(!compareTrace(spike,zero).passed);assert.equal(compareTrace(spike,zero).peakIndex,99);assert.throws(()=>compareTrace([0],zero));const bad=zero.slice();bad[9]=NaN;assert.throws(()=>compareTrace(bad,zero));
const results=[];
for(const c of model.cases)for(const s of sources){const key=`${c.mode}-${c.gain}-${s.id}`,reference=JSON.parse(fs.readFileSync(new URL(key+'/reference.json',root))).reference,input=diagnosticInput(s.id);const rows=fs.readFileSync(new URL(key+'/comparison.csv',root),'utf8').trim().split('\n').slice(1).map(r=>r.split(',').map(Number));
 for(const chunk of [257,4096]){const p=new SignalProcessor(c.kernel,c.dc,input[0]),out=new Float64Array(4001);for(let i=0;i<4001;i+=chunk)out.set(p.process(input.subarray(i,i+chunk)),i);const m=compareTrace(out,reference);const difference=Math.max(...out.map((v,i)=>Math.abs(v-rows[i][3])));assert(difference<1e-12);assert(m.passed);results.push({key,chunk,peakV:m.peak,rmsV:m.rms,directDifferenceV:difference,passed:m.passed});}
}
assert.equal(results.length,72);const report={sourceChecks,comparisonGuardChecks:6,runtimeChecks:results.length,passed:true,results};fs.writeFileSync(new URL('runtime-validation.json',root),JSON.stringify(report,null,2));console.log(JSON.stringify({sourceChecks,runtimeChecks:results.length,passed:true}));
