from pathlib import Path
import json,numpy as np
ROOT=Path(__file__).resolve().parent;model=json.loads((ROOT/'runtime-model.json').read_text());sources=json.loads((ROOT/'sources.json').read_text())['sources'];grid=np.arange(4001)*.25e-9;results=[]
for c in model['cases']:
 for source in sources:
  key=f"{c['mode']}-{c['gain']}-{source['id']}";d=ROOT/key;assert json.loads((d/'record.json').read_text())['completed']
  raw=np.loadtxt(d/'tran.txt',skiprows=1);u=np.array(source['input']);reference=np.interp(grid,raw[:,0],raw[:,2]);measured=np.interp(grid,raw[:,0],raw[:,1]);source_error=float(np.max(np.abs(measured-u)));assert source_error<1e-10
  h=np.array(c['kernel']);actual=c['dc']+u[0]*sum(h)+np.convolve(u-u[0],h)[:len(u)];error=actual-reference;peak=float(np.max(abs(error)));rms=float(np.sqrt(np.mean(error**2)))
  result=dict(key=key,source=source['id'],mode=c['mode'],gain=c['gain'],peakV=peak,rmsV=rms,inputAgreementV=source_error,passed=peak<=.001 and rms<=.0001);results.append(result)
  np.savetxt(d/'comparison.csv',np.column_stack((grid,u,reference,actual,error)),delimiter=',',header='time_s,input_V,reference_V,runtime_V,error_V',comments='')
  (d/'reference.json').write_text(json.dumps(dict(source=source['id'],mode=c['mode'],gain=c['gain'],sampleNs=.25,sampleCount=4001,reference=reference.tolist()),separators=(',',':')))
(ROOT/'validation.json').write_text(json.dumps(results,indent=2));print(json.dumps(dict(cases=len(results),passed=all(r['passed'] for r in results),peakV=max(r['peakV'] for r in results),rmsV=max(r['rmsV'] for r in results)),indent=2));assert len(results)==36 and all(r['passed'] for r in results)
