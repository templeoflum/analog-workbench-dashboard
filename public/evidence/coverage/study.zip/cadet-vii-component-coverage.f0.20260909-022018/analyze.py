from pathlib import Path
import json,csv,sys,hashlib
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'cadet-vii-reference-stage.f1.20260909-010314'))
from analyze_xyce import difference

def read(r):
 path=ROOT/r['folder']/('tran.csv' if r['simulator']=='xyce' else 'tran.txt')
 if r['simulator']=='xyce':return [[float(v) for v in row] for row in list(csv.reader(path.read_text().splitlines()))[1:]]
 return [[float(v) for v in l.split()] for l in path.read_text().splitlines()[1:]]
def cards(r):return [l.strip() for l in (ROOT/r['folder']/'circuit.cir').read_text().split('.control')[0].splitlines()[1:] if l.strip() and not l.startswith(('.options','.tran','.print','.end'))]
if __name__=='__main__':
 records=json.loads((ROOT/'xyce-results.json').read_text())+json.loads((ROOT/'ngspice-results.json').read_text());assert len(records)==42
 comparisons=[];cases=[]
 for kind in ['gain1','gain2','inverting']:
  for load in [1000,100000]:
   group=[r for r in records if r['kind']==kind and r['load_ohms']==load];table={(r['simulator'],r['label']):r for r in group};traces={k:read(r) for k,r in table.items() if r['status']=='completed'}
   pairs=[]
   for sim in ['xyce','ngspice']:
    pairs.extend([(sim+' timestep coarse-middle',(sim,'coarse'),(sim,'middle')),(sim+' timestep middle-fine',(sim,'middle'),(sim,'fine'))])
   for label in ['coarse','middle','fine']:pairs.append(('cross-simulator '+label,('xyce',label),('ngspice',label)))
   pairs.append(('ngspice tighter tolerance',('ngspice','fine'),('ngspice','tight')))
   results=[]
   for label,a,b in pairs:
    assert cards(table[a])==cards(table[b]),'Electrical circuit changed across comparison'
    delta=difference(traces[a],traces[b]) if a in traces and b in traces else None
    result=dict(kind=kind,load_ohms=load,label=label,folders=[table[a]['folder'],table[b]['folder']],max_difference_v=delta)
    comparisons.append(result);results.append(result)
   trends={sim:None if any(x['max_difference_v'] is None for x in results if x['label'].startswith(sim+' timestep')) else results[0 if sim=='xyce' else 2]['max_difference_v']>results[1 if sim=='xyce' else 3]['max_difference_v'] for sim in ['xyce','ngspice']}
   cases.append(dict(kind=kind,load_ohms=load,runs=group,comparisons=results,decreasing=trends))
 summary=dict(attempted=42,completed=sum(r['status']=='completed' for r in records),model_sha256=hashlib.sha256((ROOT/'ti/lm6172.lib').read_bytes()).hexdigest(),cases=cases)
 (ROOT/'summary.json').write_text(json.dumps(summary,indent=2));(ROOT/'comparisons.json').write_text(json.dumps(comparisons,indent=2));print('complete',summary['completed'],'/',42,'; comparisons',sum(c['max_difference_v'] is not None for c in comparisons))
 print([(c['kind'],c['load_ohms'],c['decreasing']) for c in cases])
