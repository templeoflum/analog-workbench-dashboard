from pathlib import Path
import json,numpy as np
ROOT=Path(__file__).resolve().parent
checks=[]
for c in json.loads((ROOT/'comparisons.json').read_text()):
 if c['max_difference_v'] is None:continue
 traces=[]
 for name in c['folders']:
  csv=name.startswith('xyce-');traces.append(np.loadtxt(ROOT/name/('tran.csv' if csv else 'tran.txt'),delimiter=',' if csv else None,skiprows=1))
 a,b=traces;t=np.union1d(a[:,0],b[:,0]);d=float(np.max(np.abs(np.interp(t,a[:,0],a[:,2])-np.interp(t,b[:,0],b[:,2]))));assert abs(d-c['max_difference_v'])<1e-14
 checks.append(dict(kind=c['kind'],load_ohms=c['load_ohms'],label=c['label'],difference_v=d))
(ROOT/'independent-check.json').write_text(json.dumps(checks,indent=2));print(len(checks),'comparisons independently reproduced')
