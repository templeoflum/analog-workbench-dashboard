# Linear polynomial compatibility hypothesis

Replace TL074 EGND polynomial with two series E sources and FB polynomial with five parallel F sources. Both polynomials contain only linear terms and zero intercept. Match signs, gains, control-source names and terminal nodes exactly; preserve original model and transformation manifest. First test standalone reference with KLU, then six coupled cases. No adoption based on completion alone: require original-versus-candidate reference comparisons, independent checks and refinement. Do not infer hardware accuracy or a unique simulator defect.
