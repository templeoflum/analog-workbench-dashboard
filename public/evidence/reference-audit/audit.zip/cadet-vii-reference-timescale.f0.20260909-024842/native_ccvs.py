from pathlib import Path
import re,json,hashlib
ROOT=Path(__file__).resolve().parent
original=(ROOT/'ti/TL431.lib').read_text();lines=original.splitlines();changes=[]
for name,nplus,nminus,sense,gain in [('E_E23','2','N16955404','V_V16','15.6'),('E_E24','4','N16955473','V_V17','10'),('E_E25','3','N16955532','V_V18','100')]:
 matches=[i for i,l in enumerate(lines) if l.split() and l.split()[0]==name];assert len(matches)==1;i=matches[0];old=lines[i]
 assert re.sub(r'\s+','',old)==f'{name}{nplus}{nminus}VALUE{{{{I({sense})*{gain}}}}}'
 assert not re.search(r'I\(\s*'+name+r'\s*\)',original,re.I)
 new=f'H_NATIVE_{name} {nplus} {nminus} {sense} {gain}';lines[i]=new;changes.append([old,new])
text='\n'.join(lines)+'\n';(ROOT/'ti/TL431-native-ccvs.lib').write_text(text);(ROOT/'ccvs-transform.json').write_text(json.dumps(dict(changes=changes,original_sha256=hashlib.sha256((ROOT/'ti/TL431.lib').read_bytes()).hexdigest(),candidate_sha256=hashlib.sha256(text.encode()).hexdigest(),equation='V(nplus)-V(nminus)=gain*I(sense). Native H and original linear expression have the same signed relation.',scope='Candidate representation; validation required.'),indent=2))
