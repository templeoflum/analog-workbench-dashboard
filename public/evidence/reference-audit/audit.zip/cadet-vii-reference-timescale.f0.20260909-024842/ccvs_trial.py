from runner import ROOT,ng
from core import core,standalone
from check_connections import check_netlist
import native_ccvs,json
r=[]
for mode in ['offset_input','offset_thru']:
 for gain in [0,.5,1]:
  s=core(gain,.6,mode);check_netlist(s,.6);s=s.replace('../ti/TL431.lib','../ti/TL431-native-ccvs.lib')
  x=ng(f'ccvs-coupled-{mode}-g{gain}',s,.003125);r.append(dict(x,mode=mode,gain=gain));(ROOT/'ccvs-trial.json').write_text(json.dumps(r,indent=2))
