from runner import ROOT,ng
from core import standalone,core
from check_connections import check_netlist
import json
r=[]
for solver in ['klu','']:
 for preop in [False,True]:
  s=standalone(.6,12,1000)+'\nVA source_a 0 0\n'
  x=ng(f"sequence-reference-{solver or 'sparse'}-op{preop}",s,2.5,solver=solver,output='offset',preop=preop);r.append(dict(x,scope='reference',solver=solver or 'sparse',preop=preop));(ROOT/'sequence.json').write_text(json.dumps(r,indent=2))
for mode in ['offset_input','offset_thru']:
 for gain in [0,.5,1]:
  s=core(gain,.6,mode);check_netlist(s,.6)
  x=ng(f'sequence-coupled-{mode}-g{gain}',s,.003125,preop=True);r.append(dict(x,scope='coupled',mode=mode,gain=gain,preop=True));(ROOT/'sequence.json').write_text(json.dumps(r,indent=2))
