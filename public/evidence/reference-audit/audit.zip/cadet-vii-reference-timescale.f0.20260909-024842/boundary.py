from runner import ROOT,ng
from core import standalone
import json
r=[]
for step in [2.5,.0125,.003125]:
 s=standalone(.6,12,1000)+'\nVA source_a 0 0\n';x=ng(f'sparse-reference-step{step}',s,step,solver='',output='offset');r.append(dict(x,scope='reference',step=step))
for solver in ['klu','']:
 for step in [2.5,.003125]:
  s='Shunt-only diagnostic, resistive load\n.include ../ti/TL431.lib\nVCC vcc 0 12\nVA source_a 0 0\nR18 vcc ref 4990\nRLOAD ref 0 24990\nXU4 ref 0 ref TL431\n'
  x=ng(f"shunt-only-{solver or 'sparse'}-step{step}",s,step,solver=solver,output='ref');r.append(dict(x,scope='shunt-only',solver=solver or 'sparse',step=step))
 (ROOT/'boundary.json').write_text(json.dumps(r,indent=2))
