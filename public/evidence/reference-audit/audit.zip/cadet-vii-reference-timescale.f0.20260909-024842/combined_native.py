from runner import ROOT,ng
from core import standalone,core
from check_connections import check_netlist
import native_poly,native_ccvs,json
r=[]
s=standalone(.6,12,1000)+'\nVA source_a 0 0\n'
s=s.replace('../ti/TL074.lib','../ti/TL074-native-linear.lib').replace('../ti/TL431.lib','../ti/TL431-native-ccvs.lib')
r.append(dict(ng('native-both-reference',s,.003125,output='offset'),scope='reference'))
for mode in ['offset_input','offset_thru']:
 for gain in [0,.5,1]:
  s=core(gain,.6,mode);check_netlist(s,.6);s=s.replace('../ti/TL074.lib','../ti/TL074-native-linear.lib').replace('../ti/TL431.lib','../ti/TL431-native-ccvs.lib')
  x=ng(f'native-both-{mode}-g{gain}',s,.003125);r.append(dict(x,scope='coupled',mode=mode,gain=gain));(ROOT/'combined-native.json').write_text(json.dumps(r,indent=2))
