from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent
original=(ROOT/'ti/TL074.lib').read_text();lines=original.splitlines();changes=[];output=[]
assert 'POLY_MID' not in original
for l in lines:
 t=l.split()
 if t and t[0]=='EGND':
  assert t==['EGND','99','0','POLY(2)','(3,0)','(4,0)','0','.5','.5']
  new=['E_NATIVE_GND1 99 POLY_MID 3 0 .5','E_NATIVE_GND2 POLY_MID 0 4 0 .5'];output.extend(new);changes.append([l,new])
 elif t and t[0]=='FB':
  assert t==['FB','7','99','POLY(5)','VB','VC','VE','VLP','VLN','0','4.715E6','-5E6','5E6','5E6','-5E6']
  new=[f'F_NATIVE_{n} 7 99 {sense} {gain}' for n,(sense,gain) in enumerate(zip(t[4:9],t[10:15]))];output.extend(new);changes.append([l,new])
 else:output.append(l)
assert len(changes)==2
text='\n'.join(output)+'\n';(ROOT/'ti/TL074-native-linear.lib').write_text(text);(ROOT/'poly-transform.json').write_text(json.dumps(dict(changes=changes,original_sha256=hashlib.sha256((ROOT/'ti/TL074.lib').read_bytes()).hexdigest(),candidate_sha256=hashlib.sha256(text.encode()).hexdigest(),equations=['V99=.5*V3+.5*V4','I(7→99)=4.715e6*I(VB)-5e6*I(VC)+5e6*I(VE)+5e6*I(VLP)-5e6*I(VLN)'],scope='Exact linear decomposition candidate; no component parameter changes.'),indent=2))
