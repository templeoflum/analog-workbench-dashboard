from runner import ROOT,ng
from core import standalone,core
from check_connections import check_netlist
import native_poly,json
r=[]
s=standalone(.6,12,1000)+'\nVA source_a 0 0\n';s=s.replace('../ti/TL074.lib','../ti/TL074-native-linear.lib');r.append(dict(ng('poly-reference-klu',s,.003125,output='offset'),scope='reference'))
for mode in ['offset_input','offset_thru']:
 for gain in [0,.5,1]:
  s=core(gain,.6,mode);check_netlist(s,.6);s=s.replace('../ti/TL074.lib','../ti/TL074-native-linear.lib')
  x=ng(f'poly-coupled-{mode}-g{gain}',s,.003125);r.append(dict(x,scope='coupled',mode=mode,gain=gain));(ROOT/'poly-trial.json').write_text(json.dumps(r,indent=2))
