from runner import ROOT,ng
from core import standalone,core
from check_connections import check_netlist
import json
records=[]
for load in [1000,100000]:
 for step in [2.5,.0125,.003125]:
  s=standalone(.6,12,load)+'\nVA source_a 0 0\n'
  r=ng(f'reference-load{load}-step{step}',s,step,output='offset');records.append(dict(r,load_ohms=load,max_step_ns=step,scope='standalone'))
  (ROOT/'results.json').write_text(json.dumps(records,indent=2))
s=core(.5,.6,'offset_thru');check_netlist(s,.6)
s=s.replace('PULSE(0 .2 100n 1n 1n 200n 1u)','')
r=ng('coupled-no-pulse',s,.003125);records.append(dict(r,scope='coupled no pulse'));(ROOT/'results.json').write_text(json.dumps(records,indent=2))
