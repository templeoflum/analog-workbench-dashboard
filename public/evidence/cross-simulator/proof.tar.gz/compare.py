from pathlib import Path
import numpy as np,json
p=Path(__file__).resolve().parent;rec=json.loads((p/'record.json').read_text());assert rec['status']=='completed','No comparison permitted for incomplete run'
a=np.loadtxt(p/'tran.csv',delimiter=',',skiprows=1);t=np.arange(4001)*.25e-9;old=np.array(json.loads((p/'ngspice-reference.json').read_text())['reference']);new=np.interp(t,a[:,0],a[:,2]);e=new-old
r=dict(peakV=float(np.max(abs(e))),rmsV=float(np.sqrt(np.mean(e**2))),samples=4001);(p/'sample-comparison.json').write_text(json.dumps(r,indent=2));(p/'xyce-reference.json').write_text(json.dumps(dict(reference=new.tolist())));np.savetxt(p/'comparison.csv',np.column_stack((t,old,new,e)),delimiter=',',header='time_s,ngspice_V,Xyce_V,difference_V',comments='')
