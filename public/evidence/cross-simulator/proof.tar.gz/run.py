from pathlib import Path
import os,subprocess,json,csv,math,hashlib
p=Path(__file__).resolve().parent;rt=json.loads((p/'xyce-runtime.json').read_text());assert hashlib.sha256(Path(rt['executable']).read_bytes()).hexdigest()==rt['executable_sha256']
a=(p/'ngspice-circuit.cir').read_text().split('.control')[0];b=(p/'circuit.cir').read_text().split('.options device')[0];assert [l for l in a.splitlines() if not l.startswith('.options') and l.strip()]==[l for l in b.splitlines() if l.strip()]
rec=dict(attempts=1,timeoutSeconds=60,circuitBodyIdentical=True,status='failed')
try:
 r=subprocess.run([rt['executable'],'circuit.cir'],cwd=p,env=dict(os.environ,DYLD_LIBRARY_PATH=rt['library_directory']),capture_output=True,text=True,timeout=60);log=r.stdout+r.stderr;(p/'run.log').write_text(log);rec['exitCode']=r.returncode
 rows=[[float(v) for v in row] for row in list(csv.reader((p/'tran.csv').read_text().splitlines()))[1:]] if (p/'tran.csv').exists() else []
 checks=dict(exitSuccess=r.returncode==0,finite=bool(rows) and all(math.isfinite(v) for row in rows for v in row),endpoint=bool(rows) and abs(rows[-1][0]-1e-6)<1e-17,monotone=bool(rows) and all(b[0]>a[0] for a,b in zip(rows,rows[1:])),noFailureMarkers=not any(t in log.lower() for t in ['fatal','error:','time step too small','simulation aborted']))
 rec.update(checks=checks,rows=len(rows),lastTimeSeconds=rows[-1][0] if rows else None,warnings=[l for l in log.splitlines() if 'warning' in l.lower()]);rec['status']='completed' if all(checks.values()) else 'failed'
except subprocess.TimeoutExpired as e:
 (p/'run.log').write_bytes((e.stdout or b'')+(e.stderr or b''));rec['reason']='60 second timeout'
(p/'record.json').write_text(json.dumps(rec,indent=2));print(json.dumps(rec,indent=2))
