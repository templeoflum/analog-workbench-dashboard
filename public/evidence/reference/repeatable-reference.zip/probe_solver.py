from core import core
from runner import control,ROOT
import subprocess
s=core(gain=.5)+control('op\nwrdata op.txt v(output) v(ref) v(offset)\ntran .025n 500n 0 .025n\nwrdata tran.txt v(source_a) v(output) v(offset)')
variants={'klu':s.replace('.options ','.options klu '),'sparse-pivot':s.replace('.options ','.options pivtol=1e-20 pivrel=1e-6 ')}
for name,s in variants.items():
 d=ROOT/f'core-{name}';d.mkdir(exist_ok=True);(d/'circuit.cir').write_text(s)
 try:
  r=subprocess.run(['ngspice','-n','-D','ngbehavior=ps','-b','circuit.cir'],cwd=d,capture_output=True,text=True,timeout=20);log=r.stdout+r.stderr;(d/'run.log').write_text(log);print(name,[l for l in log.splitlines() if any(x in l.lower() for x in ['error','warning','aborted','rows','timestep'])],flush=True)
 except subprocess.TimeoutExpired:print(name,'timeout',flush=True)
