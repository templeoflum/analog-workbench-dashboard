from check_connections import check_netlist
from core import core
from runner import run,control,ROOT
from bisect import bisect_left
import json

def difference(a,b):
 def on(x,y):
  ts=[r[0] for r in y];err=0
  for r in x:
   j=bisect_left(ts,r[0])
   if j==0:v=y[0][2]
   else:
    l,h=y[j-1],y[j];v=l[2]+(h[2]-l[2])*(r[0]-l[0])/(h[0]-l[0])
   err=max(err,abs(r[2]-v))
  return err
 return max(on(a,b),on(b,a))
results=[]
for mode in ['offset_input','offset_thru']:
 for gain in [0,.5,1]:
  for offset in [.6]:
   key=f'{mode}-g{gain}-q{offset}'
   s=core(gain,offset,mode).replace('.options ','.options klu ')
   check_netlist(s,offset)
   try:
    anchor,w=run('anchor-nominal-'+key,s+control('op\nwrdata op.txt v(output) v(ref) v(offset)'),['op.txt'])
    _,fullout,shunt,fulloffset=anchor['op.txt'][0]
    runs=[];traces=[]
    for label,step in [('base',.025),('half',.0125)]:
     name='frozen-nominal-'+key+'-'+label
     frozen=s.replace('XU4 ref 0 ref TL431',f'VREF_FROZEN ref 0 {shunt:.17g}')
     data,warnings=run(name,frozen+control(f'op\nwrdata op.txt v(output) v(offset)\ntran {step}n 500n 0 {step}n\nwrdata tran.txt v(source_a) v(output) v(offset)'),['op.txt','tran.txt'])
     t=data['tran.txt'];assert abs(t[-1][0]-500e-9)<1e-18
     runs.append(dict(name=name,step_ns=step,rows=len(t),warnings=warnings,output_initial_difference_v=data['op.txt'][0][1]-fullout,offset_initial_difference_v=data['op.txt'][0][2]-fulloffset,initial_transient_difference_v=t[0][2]-fullout))
     traces.append(t)
    results.append(dict(status='completed',mode=mode,gain=gain,offset=offset,shunt_frozen_v=shunt,full_dc_output_v=fullout,anchor_warnings=w,runs=runs,refinement_difference_v=difference(*traces)))
    print(key,'complete',flush=True)
   except (RuntimeError,FileNotFoundError) as e:
    results.append(dict(status='failed',mode=mode,gain=gain,offset=offset,reason=str(e)));print(key,'failed',flush=True)
   (ROOT/'frozen-nominal.json').write_text(json.dumps(results,indent=2))
