from core import standalone
from runner import run,control,ROOT
import json
results=[]
for rails in [11,12,15]:
 for offset in [0,.25,.5,.75,1]:
  for load in [1000,10000,1000000]:
   name=f'ref-dc-v{rails}-q{offset}-r{load}'
   data,w=run(name,standalone(offset,rails,load)+control('op\nwrdata op.txt v(ref) v(div) v(pos) v(neg) v(offset)'),['op.txt'])
   _,ref,div,pos,neg,out=data['op.txt'][0]
   ika=(rails-ref)/4990-(ref-div)/4990
   results.append(dict(rails=rails,offset=offset,load=load,ref_v=ref,positive_v=pos,negative_v=neg,offset_v=out,cathode_plus_feedback_current_a=ika,warnings=w))
(ROOT/'reference-dc.json').write_text(json.dumps(results,indent=2))
print('DC cases:',len(results),'ref range:',min(r['ref_v'] for r in results),max(r['ref_v'] for r in results),flush=True)
tr=[]
for offset in [0,.5,1]:
 for tight in [False,True]:
  name=f'ref-ripple-q{offset}-'+('tight' if tight else 'base')
  s=standalone(offset,12,1000).replace('VCC vcc 0 12','VCC vcc 0 DC 12 PULSE(12 12.1 10u 1u 1u 30u 100u)')
  if tight:s=s.replace('reltol=1e-6 abstol=1e-12 vntol=1e-9','reltol=1e-7 abstol=1e-13 vntol=1e-10')
  step='5n' if tight else '10n'
  data,w=run(name,s+control(f'op\ntran {step} 60u 0 {step}\nwrdata tran.txt v(vcc) v(offset) v(ref)'),['tran.txt'])
  assert abs(data['tran.txt'][-1][0]-60e-6)<1e-15
  tr.append(dict(offset=offset,tight=tight,rows=len(data['tran.txt']),warnings=w,folder=name))
(ROOT/'reference-transient.json').write_text(json.dumps(tr,indent=2));print('Supply perturbation runs:',len(tr),flush=True)
