from pathlib import Path
from bisect import bisect_left
import csv,json,math
ROOT=Path(__file__).resolve().parent

def read(path):
 rows=[[float(v) for v in r] for r in list(csv.reader(path.read_text().splitlines()))[1:]]
 assert rows and all(math.isfinite(v) for r in rows for v in r)
 assert all(b[0]>a[0] for a,b in zip(rows,rows[1:]))
 assert abs(rows[-1][0]-500e-9)<1e-18
 return rows

def difference(a,b):
 def on(x,y):
  times=[r[0] for r in y];err=0
  for r in x:
   j=bisect_left(times,r[0])
   if j==0:value=y[0][2]
   elif j==len(y):
    assert abs(r[0]-times[-1])<1e-18;value=y[-1][2]
   else:
    lo,hi=y[j-1],y[j];value=lo[2]+(hi[2]-lo[2])*(r[0]-lo[0])/(hi[0]-lo[0])
   err=max(err,abs(r[2]-value))
  return err
 return max(on(a,b),on(b,a))

if __name__=='__main__':
 records=json.loads((ROOT/'xyce-study.json').read_text());results=[]
 for mode in ['offset_input','offset_thru']:
  for gain in [0,.5,1]:
   group=[r for r in records if r['mode']==mode and r['gain']==gain]
   assert len(group)==3 and all(r['status']=='completed' for r in group)
   traces=[read(ROOT/r['folder']/'tran.csv') for r in group]
   deltas=[difference(a,b) for a,b in zip(traces,traces[1:])]
   results.append(dict(mode=mode,gain=gain,differences_v=deltas,initial_output_v=traces[-1][0][2],initial_offset_v=traces[-1][0][3]))
 (ROOT/'xyce-refinement.json').write_text(json.dumps(results,indent=2))
 print('Six corrected coupled refinement records written; no accuracy threshold assigned.')
