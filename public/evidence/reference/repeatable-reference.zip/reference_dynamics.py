from core import standalone
from runner import run,control,ROOT
from bisect import bisect_left
import json

def difference(a,b,index=2):
 def on(x,y):
  ts=[r[0] for r in y];err=0
  for r in x:
   j=bisect_left(ts,r[0])
   if j==0:v=y[0][index]
   else:
    l,h=y[j-1],y[j];v=l[index]+(h[index]-l[index])*(r[0]-l[0])/(h[0]-l[0])
   err=max(err,abs(r[index]-v))
  return err
 return max(on(a,b),on(b,a))
results=[]
for offset in [0,.5,1]:
 for load in [1000,1000000]:
  rows=[];runs=[]
  for label,step,tight in [('base',10,False),('half',5,False),('quarter',2.5,False),('tighter',2.5,True)]:
   name=f'reference-gear-q{offset}-r{load}-{label}'
   s=standalone(offset,12,load).replace('.options ','.options method=gear ').replace('VCC vcc 0 12','VCC vcc 0 DC 12 PULSE(12 12.1 10u 1u 1u 30u 100u)')
   if tight:s=s.replace('reltol=1e-6 abstol=1e-12 vntol=1e-9','reltol=1e-7 abstol=1e-13 vntol=1e-10')
   data,w=run(name,s+control(f'op\nwrdata op.txt v(ref) v(offset)\ntran {step}n 60u 0 {step}n\nwrdata tran.txt v(vcc) v(offset) v(ref)'),['op.txt','tran.txt'])
   t=data['tran.txt'];assert abs(t[-1][0]-60e-6)<1e-15
   rows.append(t);runs.append(dict(name=name,step_ns=step,tighter=tight,rows=len(t),warnings=w,initial_offset_v=t[0][2],peak_departure_v=max(abs(r[2]-t[0][2]) for r in t)))
   print(name,len(t),flush=True)
  comparisons=[dict(pair=[runs[i]['name'],runs[i+1]['name']],difference_v=difference(rows[i],rows[i+1])) for i in range(3)]
  results.append(dict(offset=offset,load=load,runs=runs,comparisons=comparisons))
  (ROOT/'reference-dynamics.json').write_text(json.dumps(results,indent=2))
print('Reference dynamics cases:',len(results),flush=True)
