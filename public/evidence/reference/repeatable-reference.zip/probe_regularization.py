from core import core,standalone
from runner import control,ROOT
import subprocess
cases={}
s=core(gain=.5)+control('op\nwrdata op.txt v(output) v(ref) v(offset)\ntran .025n 500n 0 .025n\nwrdata tran.txt v(source_a) v(output) v(offset)')
for solver in ['klu','sparse']:
 for resistance in ['1e12','1e10']:
  cases[f'{solver}-shunt{resistance}']=s.replace('.options ',f'.options {solver} rshunt={resistance} ')
s=(ROOT/'ref-ripple-q0.5-tight/circuit.cir').read_text()
cases['ref-gear']=s.replace('.options ','.options method=gear ')
for name,s in cases.items():
 d=ROOT/f'probe-{name}';d.mkdir(exist_ok=True);(d/'circuit.cir').write_text(s)
 try:
  r=subprocess.run(['ngspice','-n','-D','ngbehavior=ps','-b','circuit.cir'],cwd=d,capture_output=True,text=True,timeout=15);log=r.stdout+r.stderr;(d/'run.log').write_text(log);print(name,[l for l in log.splitlines() if any(x in l.lower() for x in ['error','warning','aborted','rows','timestep'])],flush=True)
 except subprocess.TimeoutExpired as e:
  (d/'run.log').write_text('TIMEOUT');print(name,'timeout',flush=True)
