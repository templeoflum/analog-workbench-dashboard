from pathlib import Path
import subprocess, math
ROOT=Path(__file__).resolve().parent
COMMAND=['ngspice','-n','-D','ngbehavior=ps','-b','circuit.cir']
def read(path):
 rows=[[float(x) for x in l.split()] for l in path.read_text().splitlines()[1:] if l.strip()]
 if not rows or not all(math.isfinite(x) for r in rows for x in r):raise RuntimeError('Empty or nonfinite output: '+str(path))
 return rows
def run(name,netlist,outputs,timeout=30):
 d=ROOT/name;d.mkdir(exist_ok=True)
 for f in outputs:(d/f).unlink(missing_ok=True)
 (d/'circuit.cir').write_text(netlist)
 try:r=subprocess.run(COMMAND,cwd=d,capture_output=True,text=True,timeout=timeout)
 except subprocess.TimeoutExpired as e:
  (d/'run.log').write_text('TIMEOUT\n'+(e.stdout or b'').decode(errors='replace')+(e.stderr or b'').decode(errors='replace'));raise RuntimeError(name+': timeout') from e
 log=r.stdout+r.stderr;(d/'run.log').write_text(log)
 if r.returncode or any(x in log.lower() for x in ['error','aborted','timestep too small']):raise RuntimeError(name+': failed analysis; inspect log')
 data={f:read(d/f) for f in outputs}
 for f,rows in data.items():
  if len(rows)>1 and not all(b[0]>a[0] for a,b in zip(rows,rows[1:])):raise RuntimeError(name+': nonincreasing axis')
 return data,[l for l in log.splitlines() if 'warning' in l.lower()]
def control(body):return '.control\nset wr_singlescale\nset wr_vecnames\nset numdgt=15\n'+body+'\nquit\n.endc\n.end\n'
