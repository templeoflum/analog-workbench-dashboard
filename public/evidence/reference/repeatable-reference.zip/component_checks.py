from runner import run,control,ROOT
import json
results=[]
for rail in [11,12,15]:
 name=f'tl074-idle-{rail}'
 s=f"""TL074 single macro quiescent check
.include ../ti/TL074.lib
.options gmin=1e-16 reltol=1e-7 abstol=1e-13 vntol=1e-10
.temp 25
VP vp 0 {rail}
VN vn 0 {-rail}
XU 0 out vp vn out TL074
"""
 data,w=run(name,s+control('op\nwrdata op.txt v(out) i(VP) i(VN)'),['op.txt'])
 results.append(dict(rails=rail,temperature_c=25,output_v=data['op.txt'][0][1],positive_supply_a=-data['op.txt'][0][2],negative_supply_a=data['op.txt'][0][3],warnings=w))
(ROOT/'component-checks.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
