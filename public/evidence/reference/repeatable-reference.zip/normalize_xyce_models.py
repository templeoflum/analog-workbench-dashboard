from pathlib import Path
p=Path(__file__).resolve().parent/'ti'
raw=(p/'TL074.lib').read_bytes()
assert raw.endswith(b'\x1a')
s=raw[:-1].decode('ascii')
s='\n'.join(line.lstrip(' \t') for line in s.splitlines())+'\n'
assert s.count('(3,0) (4,0)')==1
s=s.replace('(3,0) (4,0)','3 0 4 0')
(p/'TL074.xyce-normalized.lib').write_text(s)
# Only whitespace, an obsolete EOF marker, and control-node pair punctuation change.
print('TL074 syntax normalized for Xyce; original retained.')
