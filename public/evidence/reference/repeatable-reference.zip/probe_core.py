from core import core
from runner import run,control
for mode in ['offset_input','offset_thru']:
 for gain in [0,.5,1]:
  name=f'core-probe-{mode}-{gain}'
  try:
   rows,w=run(name,core(gain=gain,mode=mode)+control('op\nwrdata op.txt v(output) v(ref) v(pos) v(neg) v(offset)\ntran .025n 500n 0 .025n\nwrdata tran.txt v(source_a) v(output) v(offset)'),['op.txt','tran.txt'])
   assert abs(rows['tran.txt'][-1][0]-500e-9)<1e-18
   print(name,rows['op.txt'],len(rows['tran.txt']),w,flush=True)
  except Exception as e:print(e,flush=True)
