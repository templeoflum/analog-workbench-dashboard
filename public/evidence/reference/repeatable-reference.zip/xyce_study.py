from core import core
from check_connections import check_netlist
from runner import ROOT
import subprocess,os,json,csv,math
runtime=json.loads((ROOT/'xyce-runtime.json').read_text());runtime['executable']=os.environ.get('XYCE_EXECUTABLE',runtime['executable']);runtime['library_directory']=os.environ.get('XYCE_LIBRARY_DIRECTORY',runtime['library_directory']);env=dict(os.environ,DYLD_LIBRARY_PATH=runtime['library_directory'])
results=[]
for mode in ['offset_input','offset_thru']:
 for gain in [0,.5,1]:
  for label,step in [('base',.025),('half',.0125),('quarter',.00625)]:
   name=f'xyce-corrected-{mode}-g{gain}-{label}';d=ROOT/name;d.mkdir(exist_ok=True)
   s=core(gain,.6,mode);check_netlist(s,.6)
   s='\n'.join(l for l in s.splitlines() if not l.startswith('.options')).replace('TL074.lib','TL074.xyce-normalized.lib')
   s+=f'\n.options device GMIN=1e-16\n.options timeint METHOD=gear RELTOL=1e-4 ABSTOL=1e-7\n.options nonlin-tran RELTOL=1e-4 ABSTOL=1e-7\n.tran {step}n 500n 0 {step}n\n.print tran format=csv precision=15 file=tran.csv V(source_a) V(output) V(offset) V(ref)\n.end\n'
   (d/'circuit.cir').write_text(s);(d/'tran.csv').unlink(missing_ok=True)
   try:
    out=subprocess.run([runtime['executable'],'circuit.cir'],cwd=d,env=env,capture_output=True,text=True,timeout=30);log=out.stdout+out.stderr;(d/'run.log').write_text(log)
    rows=[[float(v) for v in r] for r in list(csv.reader((d/'tran.csv').read_text().splitlines()))[1:]] if (d/'tran.csv').exists() else []
    completed=out.returncode==0 and rows and abs(rows[-1][0]-500e-9)<1e-18 and all(math.isfinite(v) for r in rows for v in r) and all(b[0]>a[0] for a,b in zip(rows,rows[1:]))
    # Eight JFETs verify that all four TL074 amplifier macros were loaded.
    import re
    assert re.search(r'J level.*?JFET.*?8',log),'Missing TL074 devices in Xyce topology'
    results.append(dict(mode=mode,gain=gain,label=label,step_ns=step,status='completed' if completed else 'failed',rows=len(rows),last_time_s=rows[-1][0] if rows else None,folder=name,warnings=[l for l in log.splitlines() if 'warning' in l.lower()]))
    print(name,results[-1]['status'],len(rows),flush=True)
   except (subprocess.TimeoutExpired,AssertionError) as e:
    results.append(dict(mode=mode,gain=gain,label=label,status='failed',reason=str(e),folder=name));print(name,'failed',flush=True)
   (ROOT/'xyce-study.json').write_text(json.dumps(results,indent=2))
