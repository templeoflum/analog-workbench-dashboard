from check_connections import check_netlist
from core import core
from runner import run,control,ROOT
import json
results=[]
for mode in ['offset_input','offset_thru']:
 for gain in [0,.5,1]:
  for offset in [0,.5,1]:
   for load in [1000,100000]:
    name=f'core-dc-{mode}-g{gain}-q{offset}-r{load}'
    s=core(gain,offset,mode,load).replace('.options ','.options klu ').replace('VB source_b 0 0','VB source_b 0 .25')
    check_netlist(s,offset)
    try:
     data,w=run(name,s+control('dc VA -0.2 1.2 .1\nwrdata dc.txt v(output) v(ref) v(offset) v(a_out) v(b_out) v(gain_out)'),['dc.txt'])
    except (RuntimeError,FileNotFoundError) as e:
     results.append(dict(mode=mode,gain=gain,offset=offset,load=load,status='failed',reason=str(e)));(ROOT/'core-dc.json').write_text(json.dumps(results,indent=2));print(name,'failed',flush=True);continue
    rows=data['dc.txt'];assert len(rows)==15
    att=100000/100499;outload=load/(load+499);errors=[]
    for r in rows:
     a=r[0]*att;b=.25*att;shift=(2*offset-1)*2.5*20000/24990
     aout=2*a-(shift if mode=='offset_input' else 0);bout=2*b-(shift if mode=='offset_thru' else 0)
     expected=((2*gain-1)*aout+bout)*.5*outload
     errors.append(r[1]-expected)
    results.append(dict(status='completed',mode=mode,gain=gain,offset=offset,load=load,rows=len(rows),warnings=w,max_ideal_difference_v=max(abs(e) for e in errors),min_output_v=min(r[1] for r in rows),max_output_v=max(r[1] for r in rows),reference_v=rows[0][2],offset_v=rows[0][3],points=[dict(input_v=r[0],output_v=r[1],difference_from_ideal_v=e) for r,e in zip(rows,errors)]))
    (ROOT/'core-dc.json').write_text(json.dumps(results,indent=2));print(name,len(rows),flush=True)
print('Integrated DC points:',sum(r.get('rows',0) for r in results),flush=True)
