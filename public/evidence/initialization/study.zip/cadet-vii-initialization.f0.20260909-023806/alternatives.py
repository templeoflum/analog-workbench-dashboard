from runner import ROOT,ng
from core import core
from check_connections import check_netlist
import json
prior=json.loads((ROOT/'results.json').read_text());r=[]
for method,solver in [('trap','klu'),('gear',''),('trap','')]:
 for x in [x for x in prior if x['kind']=='transient']:
  mode,gain=x['mode'],x['gain'];s=core(gain,.6,mode);check_netlist(s,.6)
  seed='.nodeset '+' '.join(f'v({node})={v:.17g}' for node,v in x['seeds'].items());s+='\n'+seed+'\n'
  result=ng(f"alternative-{method}-{solver or 'sparse'}-{mode}-g{gain}",s,.003125,solver=solver,method=method)
  r.append(dict(result,method=method,solver=solver or 'sparse',mode=mode,gain=gain));(ROOT/'alternatives.json').write_text(json.dumps(r,indent=2))
