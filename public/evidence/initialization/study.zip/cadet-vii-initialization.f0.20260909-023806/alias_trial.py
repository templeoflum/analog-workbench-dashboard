from runner import ROOT,ng
from core import core
from check_connections import check_netlist
import alias_models,json
r=[]
for x in [x for x in json.loads((ROOT/'results.json').read_text()) if x['kind']=='transient']:
 s=core(x['gain'],.6,x['mode']);check_netlist(s,.6)
 s=s.replace('../ti/lm6172.lib','../ti/lm6172-node-alias.lib')+'\n.nodeset '+' '.join(f'v({k})={v:.17g}' for k,v in x['seeds'].items())+'\n'
 result=ng(f"node-alias-{x['mode']}-g{x['gain']}",s,.003125);r.append(dict(result,mode=x['mode'],gain=x['gain']));(ROOT/'alias-trial.json').write_text(json.dumps(r,indent=2))
