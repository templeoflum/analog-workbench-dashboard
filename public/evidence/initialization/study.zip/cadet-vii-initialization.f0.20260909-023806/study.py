from runner import ROOT,ng
from core import core
from check_connections import check_netlist
import csv,json,subprocess,math
SOURCE=ROOT.parent/'cadet-vii-reference-stage.f1.20260909-010314'
results=[]
for mode in ['offset_input','offset_thru']:
 for gain in [0,.5,1]:
  base=core(gain,.6,mode);check_netlist(base,.6)
  row=next(iter(list(csv.reader((SOURCE/f'xyce-corrected-{mode}-g{gain}-quarter'/'tran.csv').read_text().splitlines()))[1:]));row=list(map(float,row));seed=f'.nodeset v(ref)={row[4]:.17g} v(offset)={row[3]:.17g} v(output)={row[2]:.17g}'
  for seeded in [False,True]:
   name=f'dc-{mode}-g{gain}-'+('seeded' if seeded else 'unseeded');d=ROOT/name;d.mkdir(exist_ok=True)
   s='\n'.join(l for l in base.splitlines() if not l.startswith('.options'))+'\n.options klu gmin=1e-16 method=gear reltol=1e-6 abstol=1e-12 vntol=1e-9\n'+(seed if seeded else '')+'\n.control\nset wr_singlescale\nset wr_vecnames\nset numdgt=15\nop\nwrdata dc.txt v(output) v(ref) v(offset)\nquit\n.endc\n.end\n';(d/'circuit.cir').write_text(s)
   try:
    out=subprocess.run(['ngspice','-n','-D','ngbehavior=ps','-b','circuit.cir'],cwd=d,capture_output=True,text=True,timeout=45);log=out.stdout+out.stderr;(d/'run.log').write_text(log)
    rows=[[float(v) for v in l.split()] for l in (d/'dc.txt').read_text().splitlines()[1:]] if (d/'dc.txt').exists() else []
    ok=out.returncode==0 and len(rows)==1 and all(math.isfinite(v) for v in rows[0]) and 'error' not in log.lower()
    r=dict(folder=name,mode=mode,gain=gain,seeded=seeded,kind='dc',status='completed' if ok else 'failed',values=rows[0][1:] if ok else None)
   except subprocess.TimeoutExpired as e:
    (d/'run.log').write_bytes((e.stdout or b'')+(e.stderr or b''));r=dict(folder=name,mode=mode,gain=gain,kind='dc',seeded=seeded,status='failed',reason='timeout45s')
   results.append(r);print(name,r['status'],flush=True)
  r=ng(f'transient-{mode}-g{gain}-seeded',base+'\n'+seed+'\n',.003125);results.append(dict(r,mode=mode,gain=gain,kind='transient',seeded=True,seeds=dict(output=row[2],offset=row[3],ref=row[4])))
  (ROOT/'results.json').write_text(json.dumps(results,indent=2))
