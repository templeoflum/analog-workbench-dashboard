from runner import ROOT
import json,subprocess,math,re
prior=json.loads((ROOT/'results.json').read_text());results=[]
for r in [r for r in prior if r['kind']=='dc' and r['seeded']]:
 original=(ROOT/r['folder']/'circuit.cir').read_text()
 for factor in [.9,1.1]:
  name=r['folder']+f'-factor{factor}';d=ROOT/name;d.mkdir(exist_ok=True)
  s=re.sub(r'^.nodeset.*$',lambda m:re.sub(r'(=)([-+0-9.eE]+)',lambda n:'='+format(float(n.group(2))*factor,'.17g'),m.group()),original,flags=re.M)
  (d/'circuit.cir').write_text(s)
  try:
   out=subprocess.run(['ngspice','-n','-D','ngbehavior=ps','-b','circuit.cir'],cwd=d,capture_output=True,text=True,timeout=30);log=out.stdout+out.stderr;(d/'run.log').write_text(log)
   rows=[[float(v) for v in l.split()] for l in (d/'dc.txt').read_text().splitlines()[1:]] if (d/'dc.txt').exists() else []
   ok=out.returncode==0 and len(rows)==1 and all(math.isfinite(v) for v in rows[0]) and 'error' not in log.lower()
   record=dict(folder=name,mode=r['mode'],gain=r['gain'],factor=factor,status='completed' if ok else 'failed',values=rows[0][1:] if ok else None,delta_output_v=abs(rows[0][1]-r['values'][0]) if ok else None)
  except subprocess.TimeoutExpired as e:
   (d/'run.log').write_bytes((e.stdout or b'')+(e.stderr or b''));record=dict(folder=name,mode=r['mode'],gain=r['gain'],factor=factor,status='failed',reason='timeout30s')
  results.append(record);print(name,record['status'],flush=True);(ROOT/'seed-sensitivity.json').write_text(json.dumps(results,indent=2))
