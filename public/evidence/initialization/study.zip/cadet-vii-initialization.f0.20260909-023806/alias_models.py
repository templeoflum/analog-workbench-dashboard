from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
source=(ROOT/'ti/lm6172.lib').read_text()
removed=['EXX 10 5 17 5 1.0','EEE 10 50 17 5 1.0','ECC 40 10 4 17 1.0','EPSR 42 10 4 10 1.0']
# EXX gives V10=V17; EEE then V50=V5; ECC V40=V4; EPSR V42=V4.
aliases={'10':'17','50':'5','40':'4','42':'4'}
for line in removed:assert source.splitlines().count(line)==1
names={l.split()[0] for l in removed};result=[];changes=[]
for line in source.splitlines():
 if line in removed:changes.append([line,None]);continue
 if not line.strip() or line.startswith(('*','.')):result.append(line);continue
 t=line.split();kind=t[0][0].upper();count={'R':2,'C':2,'D':2,'V':2,'I':2,'E':4,'G':4,'F':2,'H':2,'Q':3}.get(kind)
 assert count is not None,(kind,line)
 if kind in ['F','H']:assert t[3] not in names
 original=t.copy()
 for i in range(1,1+count):t[i]=aliases.get(t[i],t[i])
 out=' '.join(t) if t!=original else line
 if out!=line:changes.append([line,out])
 result.append(out)
text='\n'.join(result)+'\n';(ROOT/'ti/lm6172-node-alias.lib').write_text(text)
(ROOT/'alias-transform.json').write_text(json.dumps(dict(original_sha256=hashlib.sha256((ROOT/'ti/lm6172.lib').read_bytes()).hexdigest(),transformed_sha256=hashlib.sha256(text.encode()).hexdigest(),aliases=aliases,changes=changes,scope='Eliminate four unobserved unity-source node constraints; no component values changed. Candidate transformation, not yet qualified.'),indent=2))
