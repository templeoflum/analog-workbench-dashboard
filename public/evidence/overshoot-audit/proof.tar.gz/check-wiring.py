from pathlib import Path
from run_cadet import circuit
import json
p=Path(__file__).resolve().parent
# Authored from visual review of retained LZX Cadet VII v1.1 schematic.
expected='''R3 a 0 100000
R14 b 0 100000
R1 a a_plus 499
R12 b b_plus 499
R7 a_out a_minus 1000
R2 b_out b_minus 1000
R8 a_out gain_minus 10000
R9 gain_out gain_minus 10000
R6 gain_out sum 1000
R5 b_out sum 1000
R13 preout feedback 1000
R19 preout output 499
XU31 a_plus a_minus vcc vee a_out LM6172/NS
XU21 b_plus b_minus vcc vee b_out LM6172/NS
XU22 sum feedback vcc vee preout LM6172/NS'''.splitlines()
records=[]
for mode in ['offset_input','offset_thru']:
 for gain in [0,.5,1]:
  lines=circuit(gain=gain,offset=.6,mode=mode).splitlines();wiper='0' if gain==0 else 'a_out' if gain==1 else 'wiper';sa,sb=('offset','0') if mode=='offset_input' else ('0','offset');checks=expected+[f'R10 {sa} a_minus 1000',f'R11 {sb} b_minus 1000',f'XU32 {wiper} gain_minus vcc vee gain_out LM6172/NS']
  checks+=['R4 a_out 0 10000'] if gain in [0,1] else ['R4top a_out wiper 5000.0','R4bottom wiper 0 5000.0']
  assert all(line in lines for line in checks);records.append(dict(mode=mode,gain=gain,checkedLines=checks,passed=True))
(p/'wiring-checks.json').write_text(json.dumps(records,indent=2));print('Six configurations match visually authored connection/value checks; not an independent second schematic interpretation.')
