from pathlib import Path
import numpy as np,json
p=Path(__file__).resolve().parent;raw=np.loadtxt(p/'tran.txt',skiprows=1);assert np.isfinite(raw).all() and abs(raw[-1,0]-1e-6)<1e-17
log=(p/'run.log').read_text().lower();assert not any(t in log for t in ['error','aborted','timestep too small'])
t=np.arange(4001)*.25e-9;new=np.interp(t,raw[:,0],raw[:,2]);old=np.array(json.loads((p/'baseline.json').read_text())['reference']);error=new-old
(p/'tight.json').write_text(json.dumps(dict(reference=new.tolist())))
summary=dict(rows=len(raw),peakDifferenceV=float(abs(error).max()),rmsDifferenceV=float(np.sqrt(np.mean(error**2))),sampleCount=len(t));(p/'comparison.json').write_text(json.dumps(summary,indent=2));np.savetxt(p/'comparison.csv',np.column_stack((t,old,new,error)),delimiter=',',header='time_s,baseline_V,tight_V,difference_V',comments='');print(summary)
