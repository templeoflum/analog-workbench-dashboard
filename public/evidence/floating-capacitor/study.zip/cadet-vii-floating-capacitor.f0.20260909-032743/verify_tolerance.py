from pathlib import Path
from decimal import Decimal,localcontext
import bisect,json
ROOT=Path(__file__).resolve().parent
checks=[]
for result in [dict(steps_ns=['base','tight'],**json.loads((ROOT/'tolerance-comparison.json').read_text()))]:
 def read(step):
  rows=[[Decimal(x) for x in l.split()] for l in (ROOT/('fine-pulse-'+('tight-' if step=='tight' else '')+'TL431-grounded-state.lib-0.003125')/'state.txt').read_text().splitlines()[1:]]
  return [x[0] for x in rows],[x[2] for x in rows]
 at,av=read(result['steps_ns'][0]);bt,bv=read(result['steps_ns'][1])
 def interp(t,ts,vs):
  i=bisect.bisect_right(ts,t)-1
  if i==len(ts)-1 or ts[i]==t:return vs[i]
  return vs[i]+(vs[i+1]-vs[i])*(t-ts[i])/(ts[i+1]-ts[i])
 with localcontext() as ctx:
  ctx.prec=40
  maximum=max(abs(interp(t,at,av)-interp(t,bt,bv)) for t in sorted(set(at+bt)) if max(at[0],bt[0])<=t<=min(at[-1],bt[-1]))
 delta=abs(float(maximum)-result['max_reference_difference_V']);assert delta<1e-13
 checks.append(dict(steps_ns=result['steps_ns'],decimal_max_reference_difference_V=str(maximum),difference_from_numpy_V=delta,passed=True))
(ROOT/'independent-tolerance-check.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
