from pathlib import Path
import subprocess,json,math
ROOT=Path(__file__).resolve().parent
r=[]
for solver in ['klu','']:
 for step in [2.5,.003125]:
  name=f'grounded-{solver or "sparse"}-{step}';d=ROOT/name;d.mkdir(exist_ok=True)
  original=(Path('/Users/donovan/work/0000000/mind not map/2.structure-maintains-order/21.labor-installs-practice/211.motion-builds-form/cadet-vii-shunt-state.f0.20260909-030013')/f'{solver or "sparse"}-{step}'/'circuit.cir').read_text()
  vec='v(ref) v(xu4.2) v(xu4.3) v(xu4.4) i(v.xu4.x_h8.vh_h8)'
  text='\n'.join(('wrdata '+l.split()[1]+' '+vec) if l.startswith('wrdata ') else l for l in original.splitlines()).replace('TL431.lib','TL431-grounded-state.lib')
  (d/'circuit.cir').write_text(text)
  x=subprocess.run(['ngspice','-n','-D','ngbehavior=ps','-b','circuit.cir'],cwd=d,capture_output=True,text=True,timeout=45);log=x.stdout+x.stderr;(d/'run.log').write_text(log)
  rows=[[float(x) for x in l.split()] for l in (d/'state.txt').read_text().splitlines()[1:]] if (d/'state.txt').exists() else []
  ok=bool(rows) and x.returncode==0 and not any(t in log.lower() for t in ['error','aborted','singular','timestep too small']) and abs(rows[-1][0]-500e-9)<1e-18 and all(math.isfinite(x) for row in rows for x in row) and all(b[0]>a[0] for a,b in zip(rows,rows[1:]))
  record=dict(folder=name,completed=ok,rows=len(rows),last_time_s=rows[-1][0] if rows else None);r.append(record);print(record,flush=True)
(ROOT/'shunt-grounded.json').write_text(json.dumps(r,indent=2))
