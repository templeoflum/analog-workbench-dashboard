from pathlib import Path
from decimal import Decimal,localcontext
import json,numpy as np
ROOT=Path(__file__).resolve().parent
r=[]
for hstr in ['2.5e-9','2.5e-11','3.125e-12','3.125e-14','1e-18','3.90625e-24']:
 with localcontext() as ctx:
  ctx.prec=70
  h=Decimal(hstr);a=Decimal(1)/101;b=Decimal(1)/11;c=Decimal('80e-9')/h
  tr=a+b+2*c;det=a*b+c*(a+b);largest=(tr+(tr*tr-4*det).sqrt())/2;smallest=det/largest;condition=largest/smallest
  # Constant-input BE step at exact equilibrium. Compare floating double solve to exact DC.
  u=Decimal('-0.0010426776807624719');rhs=[a*u+c*u,-c*u]
 A=np.array([[float(a+c),-float(c)],[-float(c),float(b+c)]])
 try:
  sol=np.linalg.solve(A,np.array([float(x) for x in rhs]));error=float(max(abs(sol[0]-float(u)),abs(sol[1])));status='solved'
 except np.linalg.LinAlgError:error=None;status='singular'
 r.append(dict(step_s=hstr,BE_cap_conductance_S=str(c),decimal_condition_number=str(condition),numpy_status=status,float_max_node_error_V=error))
(ROOT/'conditioning.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
