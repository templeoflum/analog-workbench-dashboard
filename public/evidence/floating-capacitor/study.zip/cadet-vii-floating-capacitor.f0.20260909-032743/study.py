from pathlib import Path
import subprocess,json,math
ROOT=Path(__file__).resolve().parent
U0=-0.0010426776807624719
TOPOLOGIES={
'original':"""C19 n3 n4 80n
E24 n4 a24 VALUE {{I(V17)*10}}
R15 b24 a24 1
V17 b24 0 0
E25 n3 a25 VALUE {{I(V18)*100}}
R17 b25 a25 1
V18 b25 input 0""",
'floating':"""C19 n3 n4 80n
R25 n3 input 101
R24 n4 0 11""",
'grounded':"""RSTATE input state 112
CSTATE state 0 80n
E4 n4 0 input state 0.0982142857142857142857142857143
E3 n3 n4 state 0 1"""}
def run(topology,solver,step,stimulus,tight=False):
 name=f'{topology}-{solver or "sparse"}-{step}-{stimulus}'+('-tight' if tight else '')
 d=ROOT/name;d.mkdir(exist_ok=True)
 source=str(U0) if stimulus=='constant' else f'PULSE({U0} {U0+.001} 100n 1n 1n 200n 1u)'
 rel,absolute,voltage=(1e-7,1e-13,1e-10) if tight else (1e-6,1e-12,1e-9)
 text=f"""Isolated floating-capacitor benchmark
VIN input 0 {source}
{TOPOLOGIES[topology]}
.options {solver} gmin=1e-16 method=gear reltol={rel} abstol={absolute} vntol={voltage}
.control
set wr_singlescale
set wr_vecnames
set numdgt=17
tran {step}n 500n 0 {step}n
wrdata state.txt v(input) v(n3) v(n4)
quit
.endc
.end
"""
 (d/'circuit.cir').write_text(text)
 record=dict(folder=name,topology=topology,solver=solver or 'sparse',step_ns=step,stimulus=stimulus,tight=tight,completed=False)
 try:
  x=subprocess.run(['ngspice','-n','-D','ngbehavior=ps','-b','circuit.cir'],cwd=d,capture_output=True,text=True,timeout=45);log=x.stdout+x.stderr;(d/'run.log').write_text(log)
  rows=[[float(x) for x in l.split()] for l in (d/'state.txt').read_text().splitlines()[1:]] if (d/'state.txt').exists() else []
  checks=dict(exit_success=x.returncode==0,solver=('Using KLU' if solver else 'Using SPARSE') in log,no_error=not any(t in log.lower() for t in ['error','aborted','singular','timestep too small']),finite=bool(rows) and all(math.isfinite(x) for row in rows for x in row),endpoint=bool(rows) and abs(rows[-1][0]-500e-9)<1e-18,monotone=bool(rows) and all(b[0]>a[0] for a,b in zip(rows,rows[1:])))
  record.update(completed=all(checks.values()),checks=checks,rows=len(rows),last_time_s=rows[-1][0] if rows else None)
 except subprocess.TimeoutExpired as e:
  (d/'run.log').write_bytes((e.stdout or b'')+(e.stderr or b''));record['reason']='timeout45s'
 (d/'record.json').write_text(json.dumps(record,indent=2));print(name,record['completed'],record.get('last_time_s'),flush=True);return record
if __name__=='__main__':
 r=[]
 for stimulus in ['constant','pulse']:
  for topology in TOPOLOGIES:
   for solver in ['klu','']:
    for step in [2.5,.003125]:
     r.append(run(topology,solver,step,stimulus));(ROOT/'results.json').write_text(json.dumps(r,indent=2))
