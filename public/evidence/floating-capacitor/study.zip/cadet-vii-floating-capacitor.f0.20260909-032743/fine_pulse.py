from pathlib import Path
import subprocess,json,math
ROOT=Path(__file__).resolve().parent
r=[]
for model in ['TL431-grounded-state.lib']:
 for step in [.0125,.00625,.003125]:
  name=f'fine-pulse-{model}-{step}';d=ROOT/name;d.mkdir(exist_ok=True)
  text=f"""Shunt reference supply-pulse comparison
.include ../ti/{model}
VCC vcc 0 PULSE(12 12.1 100n 1n 1n 200n 1u)
R18 vcc ref 4990
RLOAD ref 0 24990
XU4 ref 0 ref TL431
.options gmin=1e-16 method=gear reltol=1e-6 abstol=1e-12 vntol=1e-9
.control
set wr_singlescale
set wr_vecnames
set numdgt=17
tran {step}n 500n 0 {step}n
wrdata state.txt v(vcc) v(ref) v(xu4.2) v(xu4.3) v(xu4.4) i(v.xu4.x_h8.vh_h8)
quit
.endc
.end
"""
  (d/'circuit.cir').write_text(text)
  x=subprocess.run(['ngspice','-n','-D','ngbehavior=ps','-b','circuit.cir'],cwd=d,capture_output=True,text=True,timeout=45);log=x.stdout+x.stderr;(d/'run.log').write_text(log)
  rows=[[float(x) for x in l.split()] for l in (d/'state.txt').read_text().splitlines()[1:]] if (d/'state.txt').exists() else []
  ok=bool(rows) and x.returncode==0 and 'Using SPARSE' in log and not any(t in log.lower() for t in ['error','aborted','singular','timestep too small']) and abs(rows[-1][0]-500e-9)<1e-16 and all(math.isfinite(x) for row in rows for x in row) and all(b[0]>a[0] for a,b in zip(rows,rows[1:]))
  record=dict(folder=name,model=model,step_ns=step,completed=ok,rows=len(rows),last_time_s=rows[-1][0] if rows else None);r.append(record);print(record,flush=True)
(ROOT/'fine-pulse.json').write_text(json.dumps(r,indent=2))
