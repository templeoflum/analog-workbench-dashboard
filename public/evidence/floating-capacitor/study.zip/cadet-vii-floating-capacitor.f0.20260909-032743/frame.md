# Floating-capacitor linear benchmark

210 → 211 → 221 · layout positions work → motion builds form → trace audits path

Isolate TL431 C19=80 nF between nodes 3 and 4, with its equivalent 101-ohm connection from node 3 to driven node 2 and 11-ohm connection from node 4 to ground. Drive node 2 with an ideal prescribed voltage; remove the surrounding nonlinear circuit. This is a diagnostic fixture, not a replacement full-device model.

Compare original source/resistor/sense groups, literal floating resistors/capacitor, and a grounded-state representation with identical isolated input-output equations. Derive x=V3−V4, tau=(101+11)*80n=8.96 us, dx/dt=(u−x)/tau, V4=(11/112)*(u−x), V3=x+V4. The grounded representation is valid for this unloaded, ideally driven fixture only.

Constant input and a named pulse, two solvers, coarse/fine steps; compare raw voltages against analytic piecewise-linear forcing and compute capacitor and algebraic residuals. Measure companion-matrix conditioning independently; no arbitrary parameter tuning or full-model promotion.
