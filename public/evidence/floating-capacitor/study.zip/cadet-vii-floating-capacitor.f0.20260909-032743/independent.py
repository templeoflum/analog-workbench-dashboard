from pathlib import Path
from decimal import Decimal as D,getcontext
import json
getcontext().prec=60
ROOT=Path(__file__).resolve().parent
u0=D('-0.0010426776807624719');tau=D('8.96e-6')
knots=[(D(t),u0+D(v)) for t,v in [('0','0'),('100e-9','0'),('101e-9','.001'),('301e-9','.001'),('302e-9','0'),('500e-9','0')]]
def single(t,stim):
 if stim=='constant':return u0
 x=u0
 for (a,u),(b,v) in zip(knots,knots[1:]):
  if t<a:break
  h=min(t,b)-a;m=(v-u)/(b-a)
  x=u+m*(h-tau)+(x-u+m*tau)*(-h/tau).exp()
  if t<=b:return x+D(11)/112*(u+m*h-x)
 return x+D(11)/112*(u0-x)
def mul(A,B):return [[sum(A[i][k]*B[k][j] for k in range(2)) for j in range(len(B[0]))] for i in range(2)]
def inverse(A):
 d=A[0][0]*A[1][1]-A[0][1]*A[1][0]
 return [[A[1][1]/d,-A[0][1]/d],[-A[1][0]/d,A[0][0]/d]]
A=[[-(1/D('16.6')+1/D(112))/D('500e-9'),1/D(112)/D('500e-9')],[1/D(112)/D('80e-9'),-1/D(112)/D('80e-9')]]
B=[[1/D('16.6')/D('500e-9')],[D(0)]];ab=mul(inverse(A),B);aab=mul(inverse(A),ab)
tr=A[0][0]+A[1][1];det=A[0][0]*A[1][1]-A[0][1]*A[1][0];dis=(tr*tr-4*det).sqrt();l1=(tr+dis)/2;l2=(tr-dis)/2
I=[[D(1),D(0)],[D(0),D(1)]]
def double(t):
 y=[[u0],[u0]]
 for (a,u),(b,v) in zip(knots,knots[1:]):
  h=min(t,b)-a;m=(v-u)/(b-a);e1=(l1*h).exp();e2=(l2*h).exp()
  E=[[e2*I[i][j]+(e1-e2)/dis*(A[i][j]-l2*I[i][j]) for j in range(2)] for i in range(2)]
  z=mul(E,[[y[i][0]+ab[i][0]*u+aab[i][0]*m] for i in range(2)])
  y=[[-ab[i][0]*(u+m*h)-aab[i][0]*m+z[i][0]] for i in range(2)]
  if t<=b:break
 return y[1][0]+D(11)/112*(y[0][0]-y[1][0])
r=[]
for name in ['analysis','two-state-analysis']:
 for record in json.loads((ROOT/(name+'.json')).read_text()):
  w=record['worst_n3'];t=min(D(str(w['time_s'])),D('500e-9'));truth=single(t,record['stimulus']) if name=='analysis' else double(t);delta=abs(truth-D(str(w['analytic_V'])))
  assert delta<D('1e-13'),(record['folder'],delta)
  r.append(dict(scope=name,folder=record['folder'],time_s=str(t),independent_reference_V=str(truth),reference_difference_V=str(delta),passed=True))
(ROOT/'independent-reference-checks.json').write_text(json.dumps(r,indent=2));print(len(r),'independent worst-point reference checks passed; max discrepancy',max(D(x['reference_difference_V']) for x in r))
