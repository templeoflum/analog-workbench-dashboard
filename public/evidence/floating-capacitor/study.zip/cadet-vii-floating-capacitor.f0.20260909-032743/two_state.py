from study import ROOT,TOPOLOGIES,U0
import study,json
# Add the original C18 and current-driven R16.6 branch. Grounded form uses R112/C80n with exact output reconstruction.
study.TOPOLOGIES={k:v.replace('input','n2')+'\nC18 n2 0 500n\n'+('E23 n2 a23 VALUE {{I(V16)*15.6}}\nR13 b23 a23 1\nV16 b23 0 0' if k=='original' else 'R23 n2 0 16.6')+'\nGDRIVE 0 n2 input 0 0.0602409638554216867469879518072' for k,v in TOPOLOGIES.items()}
r=[]
for topology in study.TOPOLOGIES:
 for solver in ['klu','']:
  for step in [2.5,.003125]:
   # Folder identity separated from the first fixture.
   study.ROOT=ROOT/'two-state';study.ROOT.mkdir(exist_ok=True)
   r.append(study.run(topology,solver,step,'pulse'))
(ROOT/'two-state.json').write_text(json.dumps(r,indent=2))
