from pathlib import Path
import json,math
import numpy as np
ROOT=Path(__file__).resolve().parent
U0=-0.0010426776807624719;TAU=112*80e-9
knots=[(0.,U0),(100e-9,U0),(101e-9,U0+.001),(301e-9,U0+.001),(302e-9,U0),(500e-9,U0)]
def advance(x,u,m,h):
 e=-math.expm1(-h/TAU)
 return x+(u-x)*e+m*(h-TAU*e)
def analytic(ts,stimulus):
 if stimulus=='constant':return np.full_like(ts,U0),np.full_like(ts,U0),np.zeros_like(ts)
 out=[];x=U0
 states=[x]
 for (a,u),(b,v) in zip(knots,knots[1:]):
  x=advance(x,u,(v-u)/(b-a),b-a);states.append(x)
 for t in ts:
  j=min(4,max(0,next((i for i in range(5) if t<=knots[i+1][0]+1e-22),4)))
  a,u=knots[j];b,v=knots[j+1];h=max(0,min(t-a,b-a));m=(v-u)/(b-a)
  z=advance(states[j],u,m,h);inp=u+m*h;n4=11/112*(inp-z);out.append([inp,z+n4,n4])
 return np.asarray(out).T
r=[]
for record in json.loads((ROOT/'results.json').read_text()):
 f=ROOT/record['folder']/'state.txt'
 if not f.exists():continue
 a=np.loadtxt(f,skiprows=1);a=np.atleast_2d(a);u,n3,n4=analytic(a[:,0],record['stimulus']);errors=np.abs(a[:,2]-n3)
 i=int(np.argmax(errors));kcl=(a[:,2]-a[:,1])/101+a[:,3]/11
 x=a[:,2]-a[:,3];truth=n3-n4
 record.update(max_n3_error_V=float(errors[i]),max_n4_error_V=float(np.max(np.abs(a[:,3]-n4))),max_differential_error_V=float(np.max(np.abs(x-truth))),max_resistor_balance_A=float(np.max(np.abs(kcl))),worst_n3=dict(time_s=float(a[i,0]),recorded_V=float(a[i,2]),analytic_V=float(n3[i])))
 r.append(record)
(ROOT/'analysis.json').write_text(json.dumps(r,indent=2))
for x in r:print(x['folder'],x['completed'],'n3err',x['max_n3_error_V'],'differr',x['max_differential_error_V'])
