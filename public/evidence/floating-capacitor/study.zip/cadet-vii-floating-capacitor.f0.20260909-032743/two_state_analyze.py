from pathlib import Path
import json,math,numpy as np
ROOT=Path(__file__).resolve().parent
U0=-0.0010426776807624719
A=np.array([[-(1/16.6+1/112)/500e-9,1/112/500e-9],[1/112/80e-9,-1/112/80e-9]])
lam,V=np.linalg.eig(A);inv=np.linalg.inv(V);b=inv@np.array([1/16.6/500e-9,0]);initial=inv@np.array([U0,U0])
knots=[(0.,U0),(100e-9,U0),(101e-9,U0+.001),(301e-9,U0+.001),(302e-9,U0),(500e-9,U0)]
def advance(z,u,m,h):
 e=np.expm1(lam*h)
 # Modal z'=lambda*z+b*u(t).
 return z*(1+e)+b*(u*e/lam+m*(e/lam**2-h/lam))
states=[initial]
for (a,u),(c,v) in zip(knots,knots[1:]):states.append(advance(states[-1],u,(v-u)/(c-a),c-a))
r=[]
for record in json.loads((ROOT/'two-state.json').read_text()):
 a=np.loadtxt(ROOT/'two-state'/record['folder']/'state.txt',skiprows=1);truth=[]
 for t in a[:,0]:
  j=next((i for i in range(5) if t<=knots[i+1][0]+1e-22),4);t0,u=knots[j];t1,v=knots[j+1];h=max(0,min(t-t0,t1-t0));n2,x=V@advance(states[j],u,(v-u)/(t1-t0),h);n4=11/112*(n2-x);truth.append([x+n4,n4])
 truth=np.array(truth);errors=np.abs(a[:,2:4]-truth);i=int(np.argmax(errors[:,0]));record.update(max_n3_error_V=float(errors[:,0].max()),max_n4_error_V=float(errors[:,1].max()),worst_n3=dict(time_s=float(a[i,0]),recorded_V=float(a[i,2]),analytic_V=float(truth[i,0])))
 r.append(record)
(ROOT/'two-state-analysis.json').write_text(json.dumps(r,indent=2));print(json.dumps([dict(folder=x['folder'],max_n3_error_V=x['max_n3_error_V']) for x in r],indent=2))
