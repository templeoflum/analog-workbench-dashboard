from pathlib import Path
from decimal import Decimal,localcontext
import json,bisect
ROOT=Path(__file__).resolve().parent
checks=[]
for result in json.loads((ROOT/'comparisons.json').read_text()):
 step=result['step_ns']
 def read(model):
  rows=[[Decimal(x) for x in l.split()] for l in (ROOT/f'dynamic-{model}-{step}/state.txt').read_text().splitlines()[1:]]
  return [x[0] for x in rows],[x[2] for x in rows]
 at,av=read('TL431.lib');bt,bv=read('TL431-grounded-state.lib')
 def interp(t,ts,vs):
  i=bisect.bisect_right(ts,t)-1
  if i==len(ts)-1 or ts[i]==t:return vs[i]
  return vs[i]+(vs[i+1]-vs[i])*(t-ts[i])/(ts[i+1]-ts[i])
 with localcontext() as ctx:
  ctx.prec=40
  maximum=max(abs(interp(t,at,av)-interp(t,bt,bv)) for t in sorted(set(at+bt)) if max(at[0],bt[0])<=t<=min(at[-1],bt[-1]))
 delta=abs(float(maximum)-result['max_abs_difference']['reference_V'])
 assert delta<1e-13
 checks.append(dict(step_ns=step,decimal_max_reference_difference_V=str(maximum),difference_from_numpy_V=delta,passed=True))
(ROOT/'independent-waveform-checks.json').write_text(json.dumps(checks,indent=2));print(len(checks),'waveform comparisons independently reproduced')
