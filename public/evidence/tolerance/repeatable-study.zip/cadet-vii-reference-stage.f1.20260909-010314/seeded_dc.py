from core import core
from runner import run,control,ROOT
import json
results=[]
for gain,load in [(0,1000),(0,100000),(1,1000)]:
 s=core(gain,.5,'offset_input',load).replace('.options ','.options klu ').replace('VB source_b 0 0','VB source_b 0 .25')+'\n.nodeset v(ref)=2.49557 v(div)=1.997 v(pos)=1.997 v(neg)=-1.997 v(offset)=0\n'
 name=f'seeded-dc-g{gain}-r{load}'
 try:
  data,w=run(name,s+control('dc VA -0.2 1.2 .1\nwrdata dc.txt v(output) v(ref) v(offset)'),['dc.txt'])
  assert len(data['dc.txt'])==15
  results.append(dict(gain=gain,load=load,status='completed',rows=data['dc.txt'],warnings=w));print(name,'complete',flush=True)
 except RuntimeError as e:results.append(dict(gain=gain,load=load,status='failed',reason=str(e)));print(name,'failed',flush=True)
(ROOT/'seeded-dc.json').write_text(json.dumps(results,indent=2))
