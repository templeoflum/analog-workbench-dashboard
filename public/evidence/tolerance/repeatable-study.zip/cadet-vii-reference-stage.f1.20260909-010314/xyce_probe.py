from core import core
from runner import ROOT
import os,subprocess,json
runtime=json.loads((ROOT/'xyce-runtime.json').read_text());env=dict(os.environ,DYLD_LIBRARY_PATH=runtime['library_directory'])
d=ROOT/'xyce-original';d.mkdir(exist_ok=True)
s='\n'.join(l for l in core().splitlines() if not l.startswith('.options'))+'\n.options device GMIN=1e-16\n.options timeint RELTOL=1e-6 ABSTOL=1e-9\n.options nonlin-tran RELTOL=1e-6 ABSTOL=1e-9\n.tran .025n 500n 0 .025n\n.print tran format=csv precision=15 file=tran.csv V(source_a) V(output) V(offset) V(ref)\n.end\n'
(d/'circuit.cir').write_text(s)
try:
 r=subprocess.run([runtime['executable'],'circuit.cir'],cwd=d,env=env,capture_output=True,text=True,timeout=30);log=r.stdout+r.stderr;(d/'run.log').write_text(log);print(log[-5000:])
except subprocess.TimeoutExpired as e:(d/'run.log').write_text('TIMEOUT');print('timeout')
