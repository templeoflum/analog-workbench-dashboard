from core import core
from runner import control,ROOT
import subprocess
s=core().replace('lm6172.lib','lm6172-algebra-diagnostic.lib')
d=ROOT/'algebra-diagnostic';d.mkdir(exist_ok=True);(d/'circuit.cir').write_text(s+control('op\nwrdata op.txt v(output) v(ref) v(offset)\ntran .025n 500n 0 .025n\nwrdata tran.txt v(source_a) v(output) v(offset)'))
try:
 r=subprocess.run(['ngspice','-n','-D','ngbehavior=ps','-b','circuit.cir'],cwd=d,capture_output=True,text=True,timeout=20);log=r.stdout+r.stderr;(d/'run.log').write_text(log);print([l for l in log.splitlines() if any(x in l.lower() for x in ['error','warning','aborted','rows','timestep'])],flush=True)
except subprocess.TimeoutExpired:print('timeout',flush=True)
