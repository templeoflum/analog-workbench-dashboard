from core import core
from runner import ROOT,control
import subprocess,json,os
r=json.loads((ROOT/'xyce-runtime.json').read_text());env=dict(os.environ,DYLD_LIBRARY_PATH=r['library_directory']);d=ROOT/'xyce-seeded';d.mkdir(exist_ok=True)
s=core().replace('.options ','.options klu ');(d/'ng.cir').write_text(s+control('set filetype=ascii\nop\nwrite op.raw all'))
out=subprocess.run(['ngspice','-n','-D','ngbehavior=ps','-b','ng.cir'],cwd=d,capture_output=True,text=True,timeout=15);(d/'ng.log').write_text(out.stdout+out.stderr)
raw=(d/'op.raw').read_text();a,b=raw.split('Variables:\n')[1].split('Values:\n');vs=[l.split()[1:3] for l in a.splitlines() if l.strip()];ls=[l.split() for l in b.splitlines() if l.strip()];values=[float(ls[0][1])]+[float(l[0]) for l in ls[1:]]
seeds=[]
for (v,kind),value in zip(vs,values):
 if kind=='voltage' and '.' not in v:seeds.append(f'.nodeset {v}={value:.17g}')
s=(ROOT/'xyce-eof-clean/circuit.cir').read_text().replace('.end','\n'.join(seeds)+'\n.end')
(d/'circuit.cir').write_text(s)
out=subprocess.run([r['executable'],'circuit.cir'],cwd=d,env=env,capture_output=True,text=True,timeout=30);log=out.stdout+out.stderr;(d/'run.log').write_text(log);print('exit',out.returncode,'seeds',len(seeds),flush=True);print('\n'.join(l for l in log.splitlines() if any(t in l for t in ['error','Warning','warning','too small','Failed','Failed.'])))
if (d/'tran.csv').exists():print('last:',(d/'tran.csv').read_text().splitlines()[-1])
