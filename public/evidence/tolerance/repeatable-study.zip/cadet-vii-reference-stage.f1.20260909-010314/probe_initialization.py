from core import core
from runner import control,ROOT
import subprocess,re
name=ROOT/'initialization-probe';name.mkdir(exist_ok=True)
s=core()
(name/'initial.cir').write_text(s.replace('.options ','.options klu ')+control('set filetype=ascii\nop\nwrite op.raw all'))
r=subprocess.run(['ngspice','-n','-D','ngbehavior=ps','-b','initial.cir'],cwd=name,capture_output=True,text=True,timeout=15);(name/'initial.log').write_text(r.stdout+r.stderr)
raw=(name/'op.raw').read_text();a,b=raw.split('Variables:\n')[1].split('Values:\n');variables=[l.split()[1:3] for l in a.splitlines() if l.strip()];lines=[l.split() for l in b.splitlines() if l.strip()];values=[float(lines[0][1])]+[float(l[0]) for l in lines[1:]]
assert len(variables)==len(values)
conditions=[]
for (v,kind),value in zip(variables,values):
 if kind=='voltage':conditions.append(f'{v}={value:.17g}')
print('Initial voltage nodes',len(conditions),flush=True)
for method in ['nodeset','ic']:
 net=s+'\n'.join('.'+method+' '+c for c in conditions)+'\n'+control('tran .025n 500n 0 .025n'+(' uic' if method=='ic' else '')+'\nwrdata '+method+'.txt v(source_a) v(output) v(offset)')
 (name/f'{method}.cir').write_text(net)
 try:
  r=subprocess.run(['ngspice','-n','-D','ngbehavior=ps','-b',f'{method}.cir'],cwd=name,capture_output=True,text=True,timeout=20);log=r.stdout+r.stderr;(name/f'{method}.log').write_text(log);print(method,[l for l in log.splitlines() if any(x in l.lower() for x in ['error','warning','aborted','rows','timestep'])],flush=True)
 except subprocess.TimeoutExpired:print(method,'timeout',flush=True)
