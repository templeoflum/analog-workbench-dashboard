from pathlib import Path
import json,numpy as np
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'cadet-vii-reference-stage.f1.20260909-010314'
records=json.loads((ROOT/'results.json').read_text());checks=[]
for r in records:
 if r['status']!='completed':continue
 a=np.loadtxt(SOURCE/f"xyce-corrected-{r['mode']}-g{r['gain']}-quarter"/'tran.csv',delimiter=',',skiprows=1)
 b=np.loadtxt(ROOT/r['folder']/'tran.csv',delimiter=',',skiprows=1)
 grid=np.union1d(a[:,0],b[:,0]);observed=float(np.max(np.abs(np.interp(grid,a[:,0],a[:,2])-np.interp(grid,b[:,0],b[:,2]))))
 assert abs(observed-r['max_difference_v'])<1e-14
 checks.append(dict(folder=r['folder'],independent_max_difference_v=observed))
(ROOT/'independent-check.json').write_text(json.dumps(checks,indent=2));print(len(checks),'comparisons independently reproduced')
