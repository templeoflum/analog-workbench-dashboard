from pathlib import Path
import sys,json,os,subprocess,csv,math,re
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'cadet-vii-reference-stage.f1.20260909-010314'
sys.path.insert(0,str(SOURCE))
from core import core
from check_connections import check_netlist
from analyze_xyce import read,difference
runtime=json.loads((SOURCE/'xyce-runtime.json').read_text())
exe=os.environ.get('XYCE_EXECUTABLE',runtime['executable'])
env=dict(os.environ,DYLD_LIBRARY_PATH=os.environ.get('XYCE_LIBRARY_DIRECTORY',runtime['library_directory']))
results=[]
for mode in ['offset_input','offset_thru']:
 for gain in [0,.5,1]:
  baseline=read(SOURCE/f'xyce-corrected-{mode}-g{gain}-quarter'/'tran.csv')
  for label,rel,absolute in [('relative',1e-5,1e-7),('absolute',1e-4,1e-8),('both',1e-5,1e-8)]:
   folder=f'{mode}-g{gain}-{label}';d=ROOT/folder;d.mkdir(exist_ok=True)
   s=core(gain,.6,mode);check_netlist(s,.6)
   s='\n'.join(l for l in s.splitlines() if not l.startswith('.options')).replace('../ti/','../ti/').replace('TL074.lib','TL074.xyce-normalized.lib')
   s+=f'\n.options device GMIN=1e-16\n.options timeint METHOD=gear RELTOL={rel} ABSTOL={absolute}\n.options nonlin-tran RELTOL={rel} ABSTOL={absolute}\n.tran .00625n 500n 0 .00625n\n.print tran format=csv precision=15 file=tran.csv V(source_a) V(output) V(offset) V(ref)\n.end\n'
   (d/'circuit.cir').write_text(s);(d/'tran.csv').unlink(missing_ok=True)
   record=dict(mode=mode,gain=gain,setting=label,reltol=rel,abstol=absolute,folder=folder,status='failed')
   try:
    out=subprocess.run([exe,'circuit.cir'],cwd=d,env=env,capture_output=True,text=True,timeout=45)
    log=out.stdout+out.stderr;(d/'run.log').write_text(log)
    rows=[[float(v) for v in r] for r in list(csv.reader((d/'tran.csv').read_text().splitlines()))[1:]] if (d/'tran.csv').exists() else []
    checks=dict(exit_success=out.returncode==0,endpoint=bool(rows) and abs(rows[-1][0]-500e-9)<1e-18,finite=bool(rows) and all(math.isfinite(v) for r in rows for v in r),monotone=bool(rows) and all(b[0]>a[0] for a,b in zip(rows,rows[1:])),tl074_devices=bool(re.search(r'J level.*?JFET.*?8',log)))
    record.update(checks=checks,rows=len(rows),last_time_ns=rows[-1][0]*1e9 if rows else None,warnings=[l for l in log.splitlines() if 'warning' in l.lower()])
    if all(checks.values()):record.update(status='completed',max_difference_v=difference(baseline,rows))
   except subprocess.TimeoutExpired as e:
    (d/'run.log').write_bytes((e.stdout or b'')+(e.stderr or b''));record['reason']='timeout after 45 seconds'
   results.append(record);(ROOT/'results.json').write_text(json.dumps(results,indent=2));print(folder,record['status'],record.get('last_time_ns'),flush=True)
