from pathlib import Path
import subprocess,json,math

def circuit(gain=.75,offset=.5,mode='offset_thru',load=100000,tight=False):
 shift=(2*offset-1)*2.5*20000/24990
 sa,sb=('offset','0') if mode=='offset_input' else ('0','offset')
 # Endpoints are direct pot contacts; intermediate positions retain actual divider load.
 if gain==0:pot='R4 a_out 0 10000';wiper='0'
 elif gain==1:pot='R4 a_out 0 10000';wiper='a_out'
 else:pot=f'R4top a_out wiper {10000*(1-gain)}\nR4bottom wiper 0 {10000*gain}';wiper='wiper'
 return f'''Cadet VII signal path v1.1 - TI LM6172, ideal offset and rails
.include ti/lm6172.lib
.options gmin=1e-16 klu reltol={1e-6 if tight else 1e-5} abstol=1e-12 vntol={1e-9 if tight else 1e-8}
VCC vcc 0 12
VEE vee 0 -12
VA source_a 0 DC 0 AC 1 PULSE(0 .2 100n 1n 1n 200n 1u)
VB source_b 0 0
VOFF offset 0 {shift}
RsourceA source_a a 499
RsourceB source_b b 499
R3 a 0 100000
R14 b 0 100000
R1 a a_plus 499
R12 b b_plus 499
R10 {sa} a_minus 1000
R7 a_out a_minus 1000
R11 {sb} b_minus 1000
R2 b_out b_minus 1000
XU31 a_plus a_minus vcc vee a_out LM6172/NS
XU21 b_plus b_minus vcc vee b_out LM6172/NS
{pot}
R8 a_out gain_minus 10000
R9 gain_out gain_minus 10000
XU32 {wiper} gain_minus vcc vee gain_out LM6172/NS
R6 gain_out sum 1000
R5 b_out sum 1000
R13 preout feedback 1000
XU22 sum feedback vcc vee preout LM6172/NS
R19 preout output 499
Rload output 0 {load}
.control
set wr_singlescale
set wr_vecnames
op
print v(output)
ac dec 100 1000 1G
wrdata ac.txt v(output)
tran {'.05n' if tight else '.1n'} 500n
wrdata tran.txt v(source_a) v(output)
quit
.endc
.end
'''
if __name__=='__main__':
 for mode in ['offset_input','offset_thru']:
  for g in [0,.5,1]:
   for tight in [False,True]:
    name=f'c7-{mode}-g{g}-'+('tight' if tight else 'base');d=Path(name);d.mkdir(exist_ok=True)
    
    for old in ['ac.txt','tran.txt']:(d/old).unlink(missing_ok=True)
    s=circuit(gain=g,offset=.6,mode=mode,tight=tight).replace('ti/lm6172.lib','../ti/lm6172.lib');(d/'circuit.cir').write_text(s)
    try:
     out=subprocess.run(['ngspice','-n','-b','circuit.cir'],cwd=d,capture_output=True,text=True,timeout=30);(d/'run.log').write_text(out.stdout+out.stderr)
     if out.returncode or 'error' in (out.stdout+out.stderr).lower() or not all((d/f).exists() for f in ['ac.txt','tran.txt']):raise RuntimeError(f'{name}: failed analysis; inspect run.log')
     print(name,out.returncode,[x for x in (out.stdout+out.stderr).splitlines() if 'v(output)' in x or 'Warning' in x],flush=True)
    except subprocess.TimeoutExpired as exc: raise RuntimeError(f'{name}: timed out, not a valid reference') from exc
