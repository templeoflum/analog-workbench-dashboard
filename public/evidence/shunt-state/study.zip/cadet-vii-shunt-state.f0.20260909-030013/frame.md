# Original shunt internal-state audit

210 → 211 → 221 · layout positions work → motion builds form → trace audits path

Scope: replay the original shunt-only circuit at 2.5 ns and 0.003125 ns with both ngspice solvers. Record internal capacitor voltages, sense currents, source-law and external KCL residuals at accepted solution rows; these are not rejected Newton-iteration residuals. Compare first/last accepted states with DC. Follow a specific implicated component with a minimal reproduction if evidence supports it. Preserve original model and prior results. No component parameter calibration or coupled/hardware promotion without matching evidence.
