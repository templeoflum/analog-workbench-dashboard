from pathlib import Path
import numpy as np,json
ROOT=Path(__file__).resolve().parent
r=[]
for step in [2.5,1.25,.625]:
 a=np.loadtxt(ROOT/f'dynamic-TL431.lib-{step}/state.txt',skiprows=1);b=np.loadtxt(ROOT/f'dynamic-TL431-resistors.lib-{step}/state.txt',skiprows=1)
 t=np.unique(np.concatenate([a[:,0],b[:,0]]));t=t[(t>=max(a[0,0],b[0,0]))&(t<=min(a[-1,0],b[-1,0]))]
 maxima={name:float(np.max(np.abs(np.interp(t,a[:,0],a[:,j])-np.interp(t,b[:,0],b[:,j])))) for j,name in enumerate(['time','supply_V','reference_V','state2_V','state3_V','state4_V','cathode_A']) if j}
 r.append(dict(step_ns=step,points=len(t),max_abs_difference=maxima,reference_excursion_V=float(np.ptp(a[:,2]))))
(ROOT/'comparisons.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
