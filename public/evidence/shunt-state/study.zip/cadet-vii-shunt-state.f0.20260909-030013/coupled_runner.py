from probe import ROOT,run,amp
import subprocess,json,csv,math,sys

def ng(name,text,step,tighter=False,solver='klu',method='gear',output='output',preop=False):
 d=ROOT/name;d.mkdir(exist_ok=True);(d/'tran.txt').unlink(missing_ok=True)
 cards='\n'.join(l for l in text.splitlines() if not l.startswith(('.options','.print','.tran','.end')))
 rel,absolute,voltage=(1e-7,1e-13,1e-10) if tighter else (1e-6,1e-12,1e-9)
 prelude='op\n' if preop else ''
 cards+=f'\n.options {solver} gmin=1e-16 method={method} reltol={rel} abstol={absolute} vntol={voltage}\n.control\nset wr_singlescale\nset wr_vecnames\nset numdgt=15\n{prelude}tran {step}n 500n 0 {step}n\nwrdata tran.txt v(source_a) v({output})\nquit\n.endc\n.end\n'
 (d/'circuit.cir').write_text(cards);record=dict(folder=name,status='failed')
 try:
  out=subprocess.run(['ngspice','-n','-D','ngbehavior=ps','-b','circuit.cir'],cwd=d,capture_output=True,text=True,timeout=45);log=out.stdout+out.stderr;(d/'run.log').write_text(log)
  rows=[[float(v) for v in l.split()] for l in (d/'tran.txt').read_text().splitlines()[1:]] if (d/'tran.txt').exists() else []
  checks=dict(exit_success=out.returncode==0,no_error=not any(x in log.lower() for x in ['error','aborted','timestep too small']),selected_solver=('Using KLU' if solver=='klu' else 'Using SPARSE') in log,endpoint=bool(rows) and abs(rows[-1][0]-500e-9)<1e-18,finite=bool(rows) and all(math.isfinite(v) for row in rows for v in row),monotone=bool(rows) and all(b[0]>a[0] for a,b in zip(rows,rows[1:])))
  record.update(checks=checks,rows=len(rows),last_time_ns=rows[-1][0]*1e9 if rows else None,warnings=[l for l in log.splitlines() if 'warning' in l.lower()])
  if all(checks.values()):record['status']='completed'
 except subprocess.TimeoutExpired as e:
  (d/'run.log').write_bytes((e.stdout or b'')+(e.stderr or b''));record['reason']='timeout45s'
 (d/'record.json').write_text(json.dumps(record,indent=2));print(name,record['status'],flush=True);return record

