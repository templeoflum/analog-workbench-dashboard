from study import ROOT,run
import json
r=[run(f'{model}-{solver or "sparse"}-{step}',solver,step,model) for model in ['TL431-native-e24.lib','TL431-native-ccvs.lib'] for solver in ['klu',''] for step in [2.5,.003125]]
(ROOT/'candidates.json').write_text(json.dumps(r,indent=2))
