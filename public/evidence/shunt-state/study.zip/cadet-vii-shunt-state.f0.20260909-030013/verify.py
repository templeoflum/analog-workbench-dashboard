from pathlib import Path
from decimal import Decimal,localcontext
import json,bisect
ROOT=Path(__file__).resolve().parent
checks=[]
for result in json.loads((ROOT/'comparisons.json').read_text()):
 step=result['step_ns']
 def read(model):
  rows=[[Decimal(x) for x in l.split()] for l in (ROOT/f'dynamic-{model}-{step}/state.txt').read_text().splitlines()[1:]]
  return [x[0] for x in rows],[x[2] for x in rows]
 at,av=read('TL431.lib');bt,bv=read('TL431-resistors.lib')
 def interp(t,ts,vs):
  i=bisect.bisect_right(ts,t)-1
  if i==len(ts)-1 or ts[i]==t:return vs[i]
  return vs[i]+(vs[i+1]-vs[i])*(t-ts[i])/(ts[i+1]-ts[i])
 with localcontext() as ctx:
  ctx.prec=40
  maximum=max(abs(interp(t,at,av)-interp(t,bt,bv)) for t in sorted(set(at+bt)) if max(at[0],bt[0])<=t<=min(at[-1],bt[-1]))
 delta=abs(float(maximum)-result['max_abs_difference']['reference_V'])
 assert delta<1e-13
 checks.append(dict(step_ns=step,decimal_max_reference_difference_V=str(maximum),difference_from_numpy_V=delta,passed=True))
# Independently reproduce E24 relation residual and C19 differential drift.
state=[]
for name in ['klu-2.5','klu-0.003125','sparse-2.5','sparse-0.003125']:
 rows=[[Decimal(x) for x in l.split()] for l in (ROOT/name/'state.txt').read_text().splitlines()[1:]]
 dc=[Decimal(x) for x in (ROOT/name/'dc.txt').read_text().splitlines()[1].split()]
 state.append(dict(folder=name,e24_max_V=str(max(abs(v[4]-v[7]-10*v[13]) for v in rows)),c19_max_dc_drift_V=str(max(abs((v[3]-v[4])-(dc[3]-dc[4])) for v in rows))))
(ROOT/'independent-checks.json').write_text(json.dumps(dict(comparisons=checks,state=state),indent=2));print(json.dumps(dict(comparisons=checks,state=state),indent=2))
