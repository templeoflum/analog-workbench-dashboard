from run_cadet import circuit
OPTIONS='.options gmin=1e-16 reltol=1e-6 abstol=1e-12 vntol=1e-9'
def reference(offset=.6):
 if not 0<=offset<=1:raise ValueError('offset must be 0..1')
 if offset==0:pot='R20 pos neg 10000';offset_wiper='neg'
 elif offset==1:pot='R20 pos neg 10000';offset_wiper='pos'
 else:pot=f'R20top pos offset_wiper {10000*(1-offset)}\nR20bottom offset_wiper neg {10000*offset}';offset_wiper='offset_wiper'
 return f"""R18 vcc ref 4990
XU4 ref 0 ref TL431
R21 ref div 4990
R22 div 0 20000
XU51 div pos vcc vee pos TL074
R16 pos inv 1000
R15 neg inv 1000
XU52 0 inv vcc vee neg TL074
{pot}
XU53 {offset_wiper} offset vcc vee offset TL074
XU54 0 unused vcc vee unused TL074
"""
def core(gain=.5,offset=.6,mode='offset_thru',load=100000,rails=12):
 if mode not in ['offset_input','offset_thru']:raise ValueError('mode')
 if not 0<=gain<=1 or load<=0 or rails<=0:raise ValueError('controls')
 s=circuit(gain=gain,offset=offset,mode=mode,load=load,tight=True).split('.control')[0]
 s=s.replace('.include ti/lm6172.lib','.include ../ti/lm6172.lib\n.include ../ti/TL431.lib\n.include ../ti/TL074.lib')
 lines=[line for line in s.splitlines() if not line.startswith('VOFF') and not line.startswith('.options')]
 s='\n'.join(lines)+'\n'+OPTIONS+'\n'+reference(offset)
 return s.replace('VCC vcc 0 12',f'VCC vcc 0 {rails}').replace('VEE vee 0 -12',f'VEE vee 0 {-rails}')
def standalone(offset=.6,rails=12,load=1000):
 return f"""Cadet reference stage - TI models, ideal board rails
.include ../ti/TL431.lib
.include ../ti/TL074.lib
{OPTIONS}
VCC vcc 0 {rails}
VEE vee 0 {-rails}
{reference(offset)}RLOAD offset 0 {load}
"""
