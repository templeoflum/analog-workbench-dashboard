from core import core,reference

def nodes(text):
 result=set()
 for line in text.splitlines():
  parts=line.split()
  if not parts:continue
  kind=parts[0][0].upper()
  if kind in ['R','V','C']:result.update(parts[1:3])
  elif kind=='X':result.update(parts[1:-1])
 return result

def check_netlist(s,offset):
 ref=reference(offset);assert ref in s
 signal=s.replace(ref,'')
 shared=nodes(signal)&nodes(ref)
 assert shared=={'0','vcc','vee','offset'},f'Unexpected inter-stage connection: {shared}'
 # The schematic connects the stages at U5.3 output and the power rails only.
 names=[l.split()[0] for l in s.splitlines()[1:] if l and l[0].upper() in ['R','X','V','C']]
 assert len(names)==len(set(names)),'Duplicate component IDs'

if __name__=='__main__':
 for mode in ['offset_input','offset_thru']:
  for gain in [0,.5,1]:
   for offset in [0,.5,1]:check_netlist(core(gain,offset,mode),offset)
 # Independent regression: an accidental resistor bridging the two wipers must fail.
 try:check_netlist(core(.5,.5)+'Raccidental wiper offset_wiper 1\n',.5)
 except AssertionError:pass
 else:raise AssertionError('Failed to reject an inter-stage wiper bridge')
 print('18 connection-boundary checks pass; accidental wiper bridge rejected.')
