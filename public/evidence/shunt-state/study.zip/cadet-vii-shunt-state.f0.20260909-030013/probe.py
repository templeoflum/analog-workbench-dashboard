from pathlib import Path
import os,subprocess,json,csv,math
ROOT=Path(__file__).resolve().parent
runtime=json.loads((ROOT.parent/'cadet-vii-reference-stage.f1.20260909-010314'/'xyce-runtime.json').read_text())
EXE=os.environ.get('XYCE_EXECUTABLE',runtime['executable']);ENV=dict(os.environ,DYLD_LIBRARY_PATH=os.environ.get('XYCE_LIBRARY_DIRECTORY',runtime['library_directory']))
def run(name,circuit,timeout=45):
 d=ROOT/name;d.mkdir(exist_ok=True);(d/'circuit.cir').write_text(circuit);(d/'tran.csv').unlink(missing_ok=True)
 record=dict(folder=name,status='failed')
 try:
  r=subprocess.run([EXE,'circuit.cir'],cwd=d,env=ENV,capture_output=True,text=True,timeout=timeout);log=r.stdout+r.stderr;(d/'run.log').write_text(log)
  rows=[[float(v) for v in row] for row in list(csv.reader((d/'tran.csv').read_text().splitlines()))[1:]] if (d/'tran.csv').exists() else []
  record['warnings']=[l for l in log.splitlines() if 'warning' in l.lower() or 'duplicate' in l.lower()]
  checks=dict(no_duplicate_options='duplicate' not in log.lower(),exit_success=r.returncode==0,endpoint=bool(rows) and abs(rows[-1][0]-500e-9)<1e-18,finite=bool(rows) and all(math.isfinite(v) for row in rows for v in row),monotone=bool(rows) and all(b[0]>a[0] for a,b in zip(rows,rows[1:])))
  record.update(checks=checks,rows=len(rows),last_time_ns=rows[-1][0]*1e9 if rows else None)
  if all(checks.values()):record['status']='completed'
 except subprocess.TimeoutExpired as e:
  (d/'run.log').write_bytes((e.stdout or b'')+(e.stderr or b''));record['reason']='timeout45s'
 (d/'record.json').write_text(json.dumps(record,indent=2));print(name,record['status'],record.get('last_time_ns'),flush=True);return record

def amp(kind='gain2',rails=12,stimulus='PULSE(0 .2 100n 1n 1n 200n 1u)',rel=1e-5,absolute=1e-8,step=.00625,extra='',model='lm6172.lib'):
 topology={'gain1':'XAMP input output vcc vee output LM6172/NS','gain2':'XAMP input minus vcc vee output LM6172/NS\nRF output minus 1000\nRG minus 0 1000','inverting':'XAMP 0 minus vcc vee output LM6172/NS\nRI input minus 1000\nRF output minus 1000'}[kind]
 return f"""Isolated LM6172 numerical diagnostic
.include ../ti/{model}
VCC vcc 0 {rails}
VEE vee 0 {-rails}
VA source_a 0 DC 0 {stimulus}
RS source_a input 499
{topology}
RL output 0 100000
.options device GMIN=1e-16
.options timeint METHOD=gear RELTOL={rel} ABSTOL={absolute}
.options nonlin-tran RELTOL={rel} ABSTOL={absolute}
{extra}
.tran {step}n 500n 0 {step}n
.print tran format=csv precision=15 file=tran.csv V(source_a) V(output) V(XAMP:42) V(XAMP:43) V(XAMP:10)
.end
"""
if __name__=='__main__':
 results=[]
 for rails in [12,15]:
  for kind in ['gain1','gain2','inverting']:
   results.append(dict(run(f'isolated-{kind}-rails{rails}',amp(kind,rails)),kind=kind,rails=rails))
 (ROOT/'isolated-results.json').write_text(json.dumps(results,indent=2))
