from core import core
from coupled_runner import ng,ROOT
from check_connections import check_netlist
import json
s=core(.5,.6,'offset_thru');check_netlist(s,.6);s=s.replace('TL431.lib','TL431-resistors.lib')
r=[ng('coupled-resistors-'+(solver or 'sparse'),s,.003125,solver=solver) for solver in ['klu','']]
(ROOT/'coupled.json').write_text(json.dumps(r,indent=2))
