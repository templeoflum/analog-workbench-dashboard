from pathlib import Path
import numpy as np,json
ROOT=Path(__file__).resolve().parent
r=[]
for a_step,b_step in [(.0125,.00625),(.00625,.003125)]:
 a=np.loadtxt(ROOT/f'fine-pulse-TL431-resistors.lib-{a_step}/state.txt',skiprows=1);b=np.loadtxt(ROOT/f'fine-pulse-TL431-resistors.lib-{b_step}/state.txt',skiprows=1)
 t=np.unique(np.concatenate([a[:,0],b[:,0]]));t=t[(t>=max(a[0,0],b[0,0]))&(t<=min(a[-1,0],b[-1,0]))]
 r.append(dict(steps_ns=[a_step,b_step],max_reference_difference_V=float(np.max(np.abs(np.interp(t,a[:,0],a[:,2])-np.interp(t,b[:,0],b[:,2]))))))
(ROOT/'fine-comparison.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
