from pathlib import Path
import subprocess,json,math
ROOT=Path(__file__).resolve().parent
vectors=['v(ref)','v(xu4.2)','v(xu4.3)','v(xu4.4)','v(xu4.n16955404)','v(xu4.n16955532)','v(xu4.n16955473)','v(xu4.n16975344)','v(xu4.n169559021)','v(xu4.vref)','v(xu4.n16955936)','i(v.xu4.v_v16)','i(v.xu4.v_v17)','i(v.xu4.v_v18)','i(v.xu4.x_h8.vh_h8)']
def run(name,solver,step,model="TL431.lib"):
 d=ROOT/name;d.mkdir(exist_ok=True)
 text=f"""Original shunt internal-state capture
.include ../ti/{model}
VCC vcc 0 12
R18 vcc ref 4990
RLOAD ref 0 24990
XU4 ref 0 ref TL431
.options {solver} gmin=1e-16 method=gear reltol=1e-6 abstol=1e-12 vntol=1e-9
.control
set wr_singlescale
set wr_vecnames
set numdgt=17
op
wrdata dc.txt {' '.join(vectors)}
tran {step}n 500n 0 {step}n
wrdata state.txt {' '.join(vectors)}
quit
.endc
.end
"""
 (d/'circuit.cir').write_text(text)
 r=subprocess.run(['ngspice','-n','-D','ngbehavior=ps','-b','circuit.cir'],cwd=d,capture_output=True,text=True,timeout=45);log=r.stdout+r.stderr;(d/'run.log').write_text(log)
 record={'folder':name,'solver':solver or 'sparse','step_ns':step,'returncode':r.returncode,'errors':[l for l in log.splitlines() if any(t in l.lower() for t in ['error','aborted','singular','timestep too small'])]}
 if (d/'state.txt').exists():
  rows=[[float(v) for v in l.split()] for l in (d/'state.txt').read_text().splitlines()[1:]]
  dc=[float(v) for v in (d/'dc.txt').read_text().splitlines()[1].split()][1:]
  record.update(rows=len(rows),last_time_s=rows[-1][0],finite=all(math.isfinite(v) for row in rows for v in row),monotone=all(b[0]>a[0] for a,b in zip(rows,rows[1:])))
  record['completed']=r.returncode==0 and not record['errors'] and record['finite'] and record['monotone'] and abs(rows[-1][0]-500e-9)<1e-18
  record['states']={v:{'dc':dc[j],'first':rows[0][j+1],'last':rows[-1][j+1],'max_abs_dc_drift':max(abs(row[j+1]-dc[j]) for row in rows)} for j,v in enumerate(vectors)}
  residuals=[]
  for row in rows:
   ref,a,b,c,e23,e25,e24,dlo,dhi,vref,fb,i16,i17,i18,ika=row[1:]
   residuals.append([(12-ref)/4990-ref/24990-ika,a-e23-15.6*i16,c-e24-10*i17,b-e25-100*i18])
  record['max_accepted_residuals']={k:max(abs(r[j]) for r in residuals) for j,k in enumerate(['external_kcl_A','e23_V','e24_V','e25_V'])}
 else:record['completed']=False
 (d/'record.json').write_text(json.dumps(record,indent=2));print(name,record['completed'],record.get('last_time_s'),flush=True);return record
if __name__=='__main__':
 results=[run(f"{solver or 'sparse'}-{step}",solver,step) for solver in ['klu',''] for step in [2.5,.003125]]
 (ROOT/'results.json').write_text(json.dumps(results,indent=2))
