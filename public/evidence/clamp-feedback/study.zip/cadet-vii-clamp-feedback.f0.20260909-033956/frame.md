# Clamp and feedback isolation

210 → 211 → 221 · layout positions work → motion builds form → trace audits path

Compare three explicitly different diagnostic boundaries: original shunt with closed feedback; original shunt with its feedback input held at the prior DC voltage; isolated original two-diode clamp with the nonlinear sink controlled by a prescribed DC voltage. Preserve original diode parameters and supply/load circuit. Constant and supply-pulse inputs, coarse/fine steps, two solvers. Check branch currents, state and completion, then refine a minimal failing boundary if useful. Open-loop fixtures are diagnostics, not candidate replacements or device qualification. Frame any subsequent component reduction separately.
