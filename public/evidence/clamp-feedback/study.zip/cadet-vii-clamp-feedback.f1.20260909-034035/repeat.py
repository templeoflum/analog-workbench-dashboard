from pathlib import Path
import subprocess,json,hashlib
ROOT=Path(__file__).resolve().parent
source=ROOT/'clamp-klu-0.003125-constant/circuit.cir';r=[]
for i in [1,2]:
 d=ROOT/f'replay-{i}';d.mkdir(exist_ok=True);(d/'circuit.cir').write_bytes(source.read_bytes())
 x=subprocess.run(['ngspice','-n','-D','ngbehavior=ps','-b','circuit.cir'],cwd=d,capture_output=True,text=True,timeout=45);log=x.stdout+x.stderr;(d/'run.log').write_text(log)
 rows=[[float(v) for v in l.split()] for l in (d/'state.txt').read_text().splitlines()[1:]]
 r.append(dict(folder=d.name,returncode=x.returncode,failed='timestep too small' in log.lower(),last_time_s=rows[-1][0],rows=len(rows),circuit_sha256=hashlib.sha256(source.read_bytes()).hexdigest()))
assert all(x['failed'] and x['last_time_s']==2.22022643632954e-12 for x in r)
(ROOT/'replays.json').write_text(json.dumps(r,indent=2));print('Two standalone failure replays match the recorded endpoint.')
