from pathlib import Path
from decimal import Decimal as D,localcontext
import json,bisect
ROOT=Path(__file__).resolve().parent
checks=[]
for result in json.loads((ROOT/'comparisons.json').read_text()):
 def read(folder):
  rows=[[D(x) for x in l.split()] for l in (ROOT/folder/'state.txt').read_text().splitlines()[1:]];return [r[0] for r in rows],[r[2] for r in rows]
 at,av=read(result['left']);bt,bv=read(result['right'])
 def interp(t,ts,vs):
  i=bisect.bisect_right(ts,t)-1
  if i==len(ts)-1 or ts[i]==t:return vs[i]
  return vs[i]+(vs[i+1]-vs[i])*(t-ts[i])/(ts[i+1]-ts[i])
 with localcontext() as ctx:
  ctx.prec=40
  maximum=max(abs(interp(t,at,av)-interp(t,bt,bv)) for t in sorted(set(at+bt)) if max(at[0],bt[0])<=t<=min(at[-1],bt[-1]))
 delta=abs(float(maximum)-result['max_ref_difference_V']);assert delta<1e-13
 checks.append(dict(name=result['name'],decimal_max_V=str(maximum),difference_from_numpy_V=delta,passed=True))
(ROOT/'independent-comparisons.json').write_text(json.dumps(checks,indent=2));print(len(checks),'waveform maxima independently reproduced')
