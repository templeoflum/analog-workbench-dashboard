from pathlib import Path
import json,numpy as np
ROOT=Path(__file__).resolve().parent
pairs=[]
for solver in ['klu','sparse']:
 for a,b in [(.0125,.00625),(.00625,.003125)]:pairs.append((f'{solver}-{a}-to-{b}',f'translated-clamp-{solver}-{a}-pulse',f'translated-clamp-{solver}-{b}-pulse'))
pairs += [('cross-solver-fine','translated-clamp-klu-0.003125-pulse','translated-clamp-sparse-0.003125-pulse'),('reference-shift-sparse-fine','clamp-sparse-0.003125-pulse','translated-clamp-sparse-0.003125-pulse')]
r=[]
for name,left,right in pairs:
 a=np.loadtxt(ROOT/left/'state.txt',skiprows=1);b=np.loadtxt(ROOT/right/'state.txt',skiprows=1)
 assert abs(a[-1,0]-500e-9)<1e-18 and abs(b[-1,0]-500e-9)<1e-18
 t=np.unique(np.concatenate([a[:,0],b[:,0]]));t=t[(t>=max(a[0,0],b[0,0]))&(t<=min(a[-1,0],b[-1,0]))]
 r.append(dict(name=name,left=left,right=right,max_ref_difference_V=float(np.max(np.abs(np.interp(t,a[:,0],a[:,2])-np.interp(t,b[:,0],b[:,2]))))))
(ROOT/'comparisons.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
# Verify coordinate mapping for all 8 paired decks. Values and model cards must be identical.
checks=[]
for record in json.loads((ROOT/'translated.json').read_text()):
 right=ROOT/record['folder']/'circuit.cir';left=ROOT/record['folder'].removeprefix('translated-')/'circuit.cir'
 def cards(path,translated=False):
  s=path.read_text().split('.control')[0]
  if translated:s='\n'.join(l for l in s.splitlines() if not l.startswith('VLOCAL ')).replace('local0','0')
  return [l.split() for l in s.splitlines() if l.strip()]
 assert cards(left)==cards(right,True)
 checks.append(dict(left=str(left.relative_to(ROOT)),right=str(right.relative_to(ROOT)),equivalent_component_cards=True))
(ROOT/'coordinate-checks.json').write_text(json.dumps(checks,indent=2))
