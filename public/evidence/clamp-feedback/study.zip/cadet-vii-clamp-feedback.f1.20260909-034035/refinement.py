from pathlib import Path
import subprocess,json,math
ROOT=Path(__file__).resolve().parent
MODEL=(ROOT/'ti/TL431.lib').read_text();DIODE=MODEL[MODEL.lower().index('.model dclamp'):].replace('*$','')
def run(boundary,solver,step,stimulus,tight=False):
 name=f'translated-{boundary}-{solver or "sparse"}-{step}-{stimulus}'+('-tight' if tight else '');d=ROOT/name;d.mkdir(exist_ok=True)
 source='12' if stimulus=='constant' else 'PULSE(12 12.1 100n 1n 1n 200n 1u)'
 base=f'Shunt boundary isolation\nVCC vcc 0 {source}\nR18 vcc ref 4990\nRLOAD ref 0 24990\n'
 if boundary=='clamp':
  body="""VCONTROL control 0 -0.0010426776807624719
VD11 upper 0 2
D11 upper internal DCLAMP
VSENSE ref dtop 0
D12 dtop internal DCLAMP
ISINK 0 internal -0.0018048323877190762
"""+DIODE
  vectors='v(vcc) v(ref) v(internal) v(control) i(vsense)'
 else:
  body='.include ../ti/TL431.lib\n'+('VFB feedback 0 2.4955710173498153\nXU4 ref 0 feedback TL431\n' if boundary=='open-feedback' else 'XU4 ref 0 ref TL431\n')
  vectors='v(vcc) v(ref) v(xu4.n16975344) v(xu4.3) i(v.xu4.x_h8.vh_h8)'
 text=base+body+f"""
.options {solver} gmin=1e-16 method=gear reltol=1e-6 abstol=1e-12 vntol=1e-9
.control
set wr_singlescale
set wr_vecnames
set numdgt=17
tran {step}n 500n 0 {step}n
wrdata state.txt {vectors}
quit
.endc
.end
"""
 text=text.replace('VCC vcc 0 ','VCC vcc local0 ').replace('RLOAD ref 0 ','RLOAD ref local0 ').replace('VCONTROL control 0 ','VCONTROL control local0 ').replace('VD11 upper 0 ','VD11 upper local0 ').replace('ISINK 0 internal ','ISINK local0 internal ')
 text=text.replace('.options ', 'VLOCAL local0 0 -2.49507803358587\n.options ',1)
 text=text.replace('v(vcc) v(ref) v(internal) v(control)','v(vcc,local0) v(ref,local0) v(internal,local0) v(control,local0)')
 if tight:text=text.replace('reltol=1e-6 abstol=1e-12 vntol=1e-9','reltol=1e-7 abstol=1e-13 vntol=1e-10')
 (d/'circuit.cir').write_text(text)
 record=dict(folder=name,boundary=boundary,solver=solver or 'sparse',step_ns=step,stimulus=stimulus,completed=False)
 try:
  x=subprocess.run(['ngspice','-n','-D','ngbehavior=ps','-b','circuit.cir'],cwd=d,capture_output=True,text=True,timeout=45);log=x.stdout+x.stderr;(d/'run.log').write_text(log)
  rows=[[float(x) for x in l.split()] for l in (d/'state.txt').read_text().splitlines()[1:]] if (d/'state.txt').exists() else []
  checks=dict(exit_success=x.returncode==0,solver=('Using KLU' if solver else 'Using SPARSE') in log,no_error=not any(t in log.lower() for t in ['error','aborted','singular','timestep too small']),finite=bool(rows) and all(math.isfinite(x) for row in rows for x in row),endpoint=bool(rows) and abs(rows[-1][0]-500e-9)<1e-18,monotone=bool(rows) and all(b[0]>a[0] for a,b in zip(rows,rows[1:])))
  record.update(completed=all(checks.values()),checks=checks,rows=len(rows),last_time_s=rows[-1][0] if rows else None,errors=[l for l in log.splitlines() if any(w in l.lower() for w in ['singular','timestep too small','aborted'])])
  if rows:record['max_ref_drift_V']=max(abs(row[2]-rows[0][2]) for row in rows)
 except subprocess.TimeoutExpired as e:
  (d/'run.log').write_bytes((e.stdout or b'')+(e.stderr or b''));record['reason']='timeout45s'
 (d/'record.json').write_text(json.dumps(record,indent=2));print(name,record['completed'],record.get('last_time_s'),flush=True);return record
if __name__=='__main__':
 r=[]
 for solver in ['klu','']:
  for step in [.0125,.00625]:r.append(run('clamp',solver,step,'pulse'))
  r.append(run('clamp',solver,.003125,'pulse',tight=True))
 (ROOT/'refinement.json').write_text(json.dumps(r,indent=2))
