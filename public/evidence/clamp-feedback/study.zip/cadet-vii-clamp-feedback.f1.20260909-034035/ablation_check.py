from pathlib import Path
from decimal import Decimal as D
import json
ROOT=Path(__file__).resolve().parent
r=[]
for record in json.loads((ROOT/'charge-ablation.json').read_text()):
 folder=record['folder'];base=folder.removeprefix(record['ablation']+'-');a=(ROOT/base/'circuit.cir').read_text();b=(ROOT/folder/'circuit.cir').read_text();target='+ tt=5.04e-008' if record['ablation']=='no-tt' else '+ cjo=4.5e-011';replacement='+ tt=0' if record['ablation']=='no-tt' else '+ cjo=0'
 assert a.replace(target,replacement)==b
 def first(f):return [D(v) for v in (ROOT/f/'state.txt').read_text().splitlines()[1].split()]
 av,bv=first(base),first(folder);r.append(dict(folder=folder,only_requested_parameter_changed=True,initial_ref_difference_V=str(abs(av[2]-bv[2]))))
(ROOT/'ablation-checks.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
