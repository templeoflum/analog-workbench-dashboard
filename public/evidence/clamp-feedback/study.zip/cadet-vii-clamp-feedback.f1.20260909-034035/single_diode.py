from study import ROOT,DIODE
import subprocess,json,math
r=[]
for shift in [0,2.49507803358587]:
 for solver in ['klu','']:
  for step in [2.5,.003125]:
   name=f'single-{shift}-{solver or "sparse"}-{step}';d=ROOT/name;d.mkdir(exist_ok=True)
   text=f"""Single original clamp diode with current bias
VSHIFT cathode 0 {shift}
IBIAS 0 anode 0.0018048324011310513
DUT anode cathode DCLAMP
{DIODE}
.options {solver} gmin=1e-16 method=gear reltol=1e-6 abstol=1e-12 vntol=1e-9
.control
set wr_singlescale
set wr_vecnames
set numdgt=17
tran {step}n 500n 0 {step}n
wrdata state.txt v(anode) v(cathode)
quit
.endc
.end
"""
   (d/'circuit.cir').write_text(text)
   x=subprocess.run(['ngspice','-n','-D','ngbehavior=ps','-b','circuit.cir'],cwd=d,capture_output=True,text=True,timeout=45);log=x.stdout+x.stderr;(d/'run.log').write_text(log)
   rows=[[float(x) for x in l.split()] for l in (d/'state.txt').read_text().splitlines()[1:]] if (d/'state.txt').exists() else []
   checks=dict(exit_success=x.returncode==0,solver=('Using KLU' if solver else 'Using SPARSE') in log,no_error=not any(t in log.lower() for t in ['error','aborted','singular','timestep too small']),finite=bool(rows) and all(math.isfinite(x) for row in rows for x in row),endpoint=bool(rows) and abs(rows[-1][0]-500e-9)<1e-18,monotone=bool(rows) and all(b[0]>a[0] for a,b in zip(rows,rows[1:])))
   record=dict(folder=name,shift_V=shift,solver=solver or 'sparse',step_ns=step,completed=all(checks.values()),checks=checks,rows=len(rows),last_time_s=rows[-1][0] if rows else None)
   if rows:record.update(initial_diode_V=rows[0][1]-rows[0][2],max_diode_drift_V=max(abs((row[1]-row[2])-(rows[0][1]-rows[0][2])) for row in rows))
   r.append(record);print(name,record['completed'],record.get('max_diode_drift_V'),flush=True)
(ROOT/'single-diode.json').write_text(json.dumps(r,indent=2))
