from pathlib import Path
from bisect import bisect_left
import subprocess, json, math
from run_cadet import circuit
ROOT=Path(__file__).resolve().parent
LEVELS=[('h100',.1,False),('h050',.05,False),('h025',.025,False),('h0125',.0125,False),('tol',.0125,True)]
def read(path):
 rows=[[float(x) for x in l.split()] for l in path.read_text().splitlines()[1:] if l.strip()]
 assert len(rows)>2 and all(math.isfinite(x) for r in rows for x in r)
 assert all(b[0]>a[0] for a,b in zip(rows,rows[1:]))
 return rows
def diff(a,b):
 def on(x,y):
  times=[r[0] for r in y]; peak=(0,0)
  for r in x:
   assert times[0]<=r[0]<=times[-1]
   j=bisect_left(times,r[0])
   if j==0:v=y[0][2]
   else:
    l,h=y[j-1],y[j];v=l[2]+(h[2]-l[2])*(r[0]-l[0])/(h[0]-l[0])
   e=abs(r[2]-v)
   if e>peak[0]:peak=(e,r[0])
  return peak
 return max(on(a,b),on(b,a))
results=[]
for mode in ['offset_input','offset_thru']:
 for gain in [0,.5,1]:
  runs=[]; traces=[]
  for label,step,tighter in LEVELS:
   d=ROOT/f'{mode}-g{gain}-{label}';d.mkdir(exist_ok=True)
   s=circuit(gain=gain,offset=.6,mode=mode,tight=True).replace('ti/lm6172.lib','../ti/lm6172.lib').replace('tran .05n 500n',f'tran {step}n 500n 0 {step}n').replace('set wr_vecnames','set wr_vecnames\nset numdgt=15')
   if tighter:s=s.replace('reltol=1e-06 abstol=1e-12 vntol=1e-09','reltol=1e-7 abstol=1e-13 vntol=1e-10')
   assert (not tighter) or 'reltol=1e-7' in s
   (d/'circuit.cir').write_text(s)
   for f in ['ac.txt','tran.txt']:(d/f).unlink(missing_ok=True)
   out=subprocess.run(['ngspice','-n','-b','circuit.cir'],cwd=d,capture_output=True,text=True,timeout=45)
   log=out.stdout+out.stderr;(d/'run.log').write_text(log)
   assert out.returncode==0 and 'error' not in log.lower(),d
   t=read(d/'tran.txt');ac=read(d/'ac.txt');assert abs(t[-1][0]-500e-9)<1e-18
   warnings=[l for l in log.splitlines() if 'warning' in l.lower()]
   runs.append(dict(level=label,maximum_step_ns=step,tighter_tolerance=tighter,rows=len(t),warnings=warnings));traces.append(t)
   print(mode,gain,label,len(t),'warnings',len(warnings),flush=True)
  comparisons=[]
  for i in range(4):
   e,t=diff(traces[i],traces[i+1]);comparisons.append(dict(pair=[runs[i]['level'],runs[i+1]['level']],max_difference_v=e,at_ns=t*1e9))
  results.append(dict(mode=mode,gain=gain,runs=runs,comparisons=comparisons))
  (ROOT/'refinement.json').write_text(json.dumps(results,indent=2))
print(json.dumps([dict(mode=r['mode'],gain=r['gain'],differences_mV=[c['max_difference_v']*1000 for c in r['comparisons']]) for r in results],indent=2))
