from pathlib import Path
from run_cadet import circuit
import subprocess,json,math
ROOT=Path(__file__).resolve().parent
records=[]
for mode in ['offset_input','offset_thru']:
 for gain in [0,.5,1]:
  d=ROOT/f'{mode}-{gain}-ac';d.mkdir(exist_ok=True)
  s=circuit(gain=gain,offset=.6,mode=mode,load=100000,tight=True).split('.control')[0].replace('.include ti/','.include ../ti/')
  s='\n'.join(l for l in s.splitlines() if not l.startswith('.options'))+'\n.options klu method=gear gmin=1e-16 reltol=1e-6 abstol=1e-12 vntol=1e-9\n'
  s+='\n.control\nset wr_singlescale\nset wr_vecnames\nset numdgt=17\nac lin 5 1Meg 5Meg\nwrdata ac.txt v(output)\nquit\n.endc\n.end\n';(d/'circuit.cir').write_text(s)
  r=subprocess.run(['ngspice','-n','-D','ngbehavior=ps','-b','circuit.cir'],cwd=d,capture_output=True,text=True,timeout=60);log=r.stdout+r.stderr;(d/'run.log').write_text(log)
  rows=[[float(v) for v in l.split()] for l in (d/'ac.txt').read_text().splitlines()[1:]]
  ok=r.returncode==0 and len(rows)==5 and all(abs(row[0]-(i+1)*1e6)<1e-6 for i,row in enumerate(rows)) and all(math.isfinite(v) for row in rows for v in row) and not any(t in log.lower() for t in ['error','aborted','timestep too small'])
  rec=dict(mode=mode,gain=gain,completed=ok,points=rows);records.append(rec);print(mode,gain,ok,flush=True)
(ROOT/'ac-reference.json').write_text(json.dumps(records,indent=2));assert all(r['completed'] for r in records)
