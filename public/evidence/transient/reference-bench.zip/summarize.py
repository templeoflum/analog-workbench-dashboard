import json,math
from pathlib import Path
from bisect import bisect_left

def read(p):return [[float(x) for x in l.split()] for l in Path(p).read_text().splitlines()[1:] if l.strip()]
def interp(rows,t,index=2):
 ts=[row[0] for row in rows];j=bisect_left(ts,t)
 if j==0:return rows[0][index]
 if j==len(rows):return rows[-1][index]
 a,b=rows[j-1],rows[j];return a[index]+(b[index]-a[index])*(t-a[0])/(b[0]-a[0])
results=[]
for mode in ['offset_input','offset_thru']:
 for g in [0,.5,1]:
  stem=f'c7-{mode}-g{g}';a=read(stem+'-base/tran.txt');b=read(stem+'-tight/tran.txt');ac=read(stem+'-base/ac.txt');ac2=read(stem+'-tight/ac.txt')
  err=max(abs(row[2]-interp(b,row[0])) for row in a);acerr=max(abs(complex(x[1],x[2])-complex(y[1],y[2])) for x,y in zip(ac,ac2));warnings=Path(stem+'-base/run.log').read_text().count('Warning:')
  zero=a[0][2];settled=interp(b,250e-9);actual=settled-zero
  expected=(2*g-1)*.2*(100000/100499)**2
  result={'mode':mode,'gain':g,'offset':.6,'base_rows':len(a),'tight_rows':len(b),'max_timestep_refinement_difference_v':err,'max_ac_refinement_difference':acerr,'initial_output_v':zero,'step_delta_v':actual,'ideal_step_delta_v':expected,'convergence_warning_count':warnings}
  results.append(result)
print(json.dumps(results,indent=2));Path('results.json').write_text(json.dumps(results,indent=2))
