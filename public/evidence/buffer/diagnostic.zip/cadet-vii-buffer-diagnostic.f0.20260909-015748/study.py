from pathlib import Path
import sys,json,os,subprocess,csv,math,re
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'cadet-vii-reference-stage.f1.20260909-010314'
sys.path.insert(0,str(SOURCE))
from core import core
from check_connections import check_netlist
from analyze_xyce import read,difference
runtime=json.loads((SOURCE/'xyce-runtime.json').read_text())
exe=os.environ.get('XYCE_EXECUTABLE',runtime['executable'])
env=dict(os.environ,DYLD_LIBRARY_PATH=os.environ.get('XYCE_LIBRARY_DIRECTORY',runtime['library_directory']))
results=[]
for mode in ['offset_input','offset_thru']:
 for gain in [0,.5,1]:
  baseline=read(SOURCE/f'xyce-corrected-{mode}-g{gain}-quarter'/'tran.csv')
  for label,rel,absolute in [('nominal',1e-4,1e-7),('both',1e-5,1e-8)]:
   folder=f'{mode}-g{gain}-{label}';d=ROOT/folder;d.mkdir(exist_ok=True)
   s=core(gain,.6,mode);check_netlist(s,.6)
   original=s
   substitutions={'XU51 div pos vcc vee pos TL074':'EDIAG51 pos 0 div pos 1e6','XU52 0 inv vcc vee neg TL074':'EDIAG52 neg 0 0 inv 1e6','XU53 offset_wiper offset vcc vee offset TL074':'EDIAG53 offset 0 offset_wiper offset 1e6','XU54 0 unused vcc vee unused TL074':'EDIAG54 unused 0 0 unused 1e6'}
   for before,after in substitutions.items():
    assert s.count(before)==1;s=s.replace(before,after)
   changed=[(a,b) for a,b in zip(original.splitlines(),s.splitlines()) if a!=b]
   assert changed==list(substitutions.items())
   assert len(original.splitlines())==len(s.splitlines())
   assert 'XU4 ref 0 ref TL431' in s and sum(l.startswith('X') and l.endswith(' LM6172/NS') for l in s.splitlines())==4
   s='\n'.join(l for l in s.splitlines() if not l.startswith('.options')).replace('../ti/','../ti/').replace('TL074.lib','TL074.xyce-normalized.lib')
   s+=f'\n.options device GMIN=1e-16\n.options timeint METHOD=gear RELTOL={rel} ABSTOL={absolute}\n.options nonlin-tran RELTOL={rel} ABSTOL={absolute}\n.tran .00625n 500n 0 .00625n\n.print tran format=csv precision=15 file=tran.csv V(source_a) V(output) V(offset) V(ref)\n.end\n'
   (d/'circuit.cir').write_text(s);(d/'tran.csv').unlink(missing_ok=True)
   record=dict(mode=mode,gain=gain,setting=label,reltol=rel,abstol=absolute,folder=folder,status='failed',diagnostic_open_loop_gain=1e6,substitution_lines=4)
   try:
    out=subprocess.run([exe,'circuit.cir'],cwd=d,env=env,capture_output=True,text=True,timeout=45)
    log=out.stdout+out.stderr;(d/'run.log').write_text(log)
    rows=[[float(v) for v in r] for r in list(csv.reader((d/'tran.csv').read_text().splitlines()))[1:]] if (d/'tran.csv').exists() else []
    checks=dict(exit_success=out.returncode==0,endpoint=bool(rows) and abs(rows[-1][0]-500e-9)<1e-18,finite=bool(rows) and all(math.isfinite(v) for r in rows for v in r),monotone=bool(rows) and all(b[0]>a[0] for a,b in zip(rows,rows[1:])),tl074_removed=not bool(re.search(r'J level.*?JFET',log)))
    record.update(checks=checks,rows=len(rows),last_time_ns=rows[-1][0]*1e9 if rows else None,warnings=[l for l in log.splitlines() if 'warning' in l.lower()])
    if all(checks.values()):record.update(status='completed',full_model_difference_v=difference(baseline,rows),initial_output_difference_v=abs(baseline[0][2]-rows[0][2]))
   except subprocess.TimeoutExpired as e:
    (d/'run.log').write_bytes((e.stdout or b'')+(e.stderr or b''));record['reason']='timeout after 45 seconds'
   results.append(record);(ROOT/'results.json').write_text(json.dumps(results,indent=2));print(folder,record['status'],record.get('last_time_ns'),flush=True)
