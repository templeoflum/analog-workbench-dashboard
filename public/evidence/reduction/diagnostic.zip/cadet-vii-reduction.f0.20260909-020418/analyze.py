from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'cadet-vii-reference-stage.f1.20260909-010314'
sys.path.insert(0,str(SOURCE))
from analyze_xyce import read,difference
records=json.loads((ROOT/'results.json').read_text());cases=[]
assert len(records)==12
for mode in ['offset_input','offset_thru']:
 for gain in [0,.5,1]:
  group=[r for r in records if r['mode']==mode and r['gain']==gain]
  assert len(group)==2
  delta=None
  if all(r['status']=='completed' for r in group):delta=difference(*[read(ROOT/r['folder']/'tran.csv') for r in group])
  cases.append(dict(mode=mode,gain=gain,runs=group,buffer_tolerance_difference_v=delta))
summary=dict(completed=sum(r['status']=='completed' for r in records),attempted=len(records),cases=cases)
(ROOT/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
