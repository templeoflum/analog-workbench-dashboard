from probe import ROOT
import json,numpy as np
r=json.loads((ROOT/'component-comparison.json').read_text());checks=[]
for c in r:
 if c['difference_v'] is None:continue
 a=np.loadtxt(ROOT/c['xyce_nominal']['folder']/'tran.csv',delimiter=',',skiprows=1);b=np.loadtxt(ROOT/c['ngspice']['folder']/'tran.txt',skiprows=1)
 t=np.union1d(a[:,0],b[:,0]);v=float(np.max(np.abs(np.interp(t,a[:,0],a[:,2])-np.interp(t,b[:,0],b[:,2]))));assert abs(v-c['difference_v'])<1e-14;checks.append(dict(kind=c['kind'],rails=c['rails'],difference_v=v))
(ROOT/'component-independent-check.json').write_text(json.dumps(checks,indent=2));print(len(checks),'same-circuit comparisons independently reproduced')
