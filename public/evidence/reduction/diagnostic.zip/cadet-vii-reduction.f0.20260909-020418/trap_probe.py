from probe import ROOT,run,amp
import json
results=[]
for mask in [False,True]:
 text=amp(kind='gain1',extra='.options timeint MASKIVARS=1' if mask else '').replace('METHOD=gear','METHOD=trap')
 results.append(run('solver-trap-corrected'+('-mask' if mask else ''),text))
(ROOT/'trap-corrected-results.json').write_text(json.dumps(results,indent=2))
