from probe import ROOT
import subprocess,json,math
r=[]
for rails in [12,15]:
 source=ROOT/f'ngspice-inverting-rails{rails}'/'circuit.cir';d=ROOT/f'ngspice-inverting-rails{rails}-klu';d.mkdir(exist_ok=True)
 (d/'circuit.cir').write_text(source.read_text().replace('.options gmin=','.options klu gmin='));record=dict(folder=d.name,rails=rails,status='failed')
 try:
  out=subprocess.run(['ngspice','-n','-D','ngbehavior=ps','-b','circuit.cir'],cwd=d,capture_output=True,text=True,timeout=45);log=out.stdout+out.stderr;(d/'run.log').write_text(log)
  rows=[[float(v) for v in l.split()] for l in (d/'tran.txt').read_text().splitlines()[1:]] if (d/'tran.txt').exists() else []
  ok=out.returncode==0 and not any(e in log.lower() for e in ['error','aborted','timestep too small']) and rows and abs(rows[-1][0]-500e-9)<1e-18 and all(math.isfinite(v) for row in rows for v in row) and all(b[0]>a[0] for a,b in zip(rows,rows[1:]))
  record.update(status='completed' if ok else 'failed',rows=len(rows),last_time_ns=rows[-1][0]*1e9 if rows else None)
 except subprocess.TimeoutExpired as e:
  (d/'run.log').write_bytes((e.stdout or b'')+(e.stderr or b''));record['reason']='timeout45s'
 (d/'record.json').write_text(json.dumps(record,indent=2));r.append(record);print(d.name,record['status'],flush=True)
 (ROOT/'klu-results.json').write_text(json.dumps(r,indent=2))
