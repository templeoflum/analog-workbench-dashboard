from probe import ROOT,run,amp
import json
cases=[('mask','.options timeint MASKIVARS=1'),('newlte0','.options timeint NEWLTE=0'),('trap','.options timeint METHOD=trap'),('nonlinear100','.options nonlin-tran MAXSTEP=100'),('mask-trap','.options timeint MASKIVARS=1 METHOD=trap')]
results=[]
for name,options in cases:
 results.append(dict(run('solver-'+name,amp(extra=options,kind='gain1')),options=options))
(ROOT/'solver-results.json').write_text(json.dumps(results,indent=2))
