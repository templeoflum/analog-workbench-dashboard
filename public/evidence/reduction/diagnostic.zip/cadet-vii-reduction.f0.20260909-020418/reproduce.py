from probe import ROOT,run,amp
import json
r=[run('replay-follower-tight-1',amp(kind='gain1')),run('replay-follower-tight-2',amp(kind='gain1')),run('control-follower-no-pulse',amp(kind='gain1',stimulus=''))]
(ROOT/'reproduction-results.json').write_text(json.dumps(r,indent=2))
