from pathlib import Path
import numpy as np,json
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'cadet-vii-reference-stage.f1.20260909-010314'
summary=json.loads((ROOT/'summary.json').read_text());checks=[]
def array(path):return np.loadtxt(path,delimiter=',',skiprows=1)
def delta(a,b):
 t=np.union1d(a[:,0],b[:,0]);return float(np.max(np.abs(np.interp(t,a[:,0],a[:,2])-np.interp(t,b[:,0],b[:,2]))))
for c in summary['cases']:
 base=array(SOURCE/f"xyce-corrected-{c['mode']}-g{c['gain']}-quarter"/'tran.csv')
 traces=[]
 for r in c['runs']:
  if r['status']!='completed':continue
  a=array(ROOT/r['folder']/'tran.csv');v=delta(base,a);assert abs(v-r['full_model_difference_v'])<1e-14
  checks.append(dict(folder=r['folder'],kind='different circuit',max_difference_v=v));traces.append(a)
 if len(traces)==2:
  v=delta(*traces);assert abs(v-c['buffer_tolerance_difference_v'])<1e-14
  checks.append(dict(mode=c['mode'],gain=c['gain'],kind='same substituted circuit tolerance',max_difference_v=v))
(ROOT/'independent-check.json').write_text(json.dumps(checks,indent=2));print(len(checks),'independent comparisons reproduced')
