from probe import ROOT
import json,sys,csv
sys.path.insert(0,str(ROOT.parent/'cadet-vii-reference-stage.f1.20260909-010314'))
from analyze_xyce import difference
records=json.loads((ROOT/'cross-component-results.json').read_text());tight=json.loads((ROOT/'isolated-results.json').read_text());cases=[]
for rails in [12,15]:
 for kind in ['gain1','gain2','inverting']:
  x=next(r for r in records if r['rails']==rails and r['kind']==kind and r['simulator']=='Xyce');n=next(r for r in records if r['rails']==rails and r['kind']==kind and r['simulator']=='ngspice');t=next(r for r in tight if r['rails']==rails and r['kind']==kind)
  n=dict(n,solver='default')
  if n['status']!='completed':
   candidate=ROOT/(n['folder']+'-klu')/'record.json'
   if candidate.exists():
    n=dict(json.loads(candidate.read_text()),simulator='ngspice',solver='KLU fallback',kind=kind,prior_attempt=n)
  delta=None
  if x['status']==n['status']=='completed':
   a=[[float(v) for v in row] for row in list(csv.reader((ROOT/x['folder']/'tran.csv').read_text().splitlines()))[1:]]
   b=[[float(v) for v in row.split()] for row in (ROOT/n['folder']/'tran.txt').read_text().splitlines()[1:]]
   delta=difference(a,b)
  cases.append(dict(rails=rails,kind=kind,xyce_nominal=x,xyce_tight=t,ngspice=n,difference_v=delta))
(ROOT/'component-comparison.json').write_text(json.dumps(cases,indent=2));print([(c['rails'],c['kind'],c['difference_v']) for c in cases])
