from probe import ROOT,run,amp
import re,json,hashlib
original=(ROOT/'ti/lm6172.lib').read_text()
assert original.count('EPSR 42 10 4 10 1.0')==1
# V(42)-V(10)=V(4)-V(10), hence V(42)=V(4).
# EPSR branch current is not referenced by any current-controlled device.
assert not any(l.split()[0][0].upper() in ['F','H'] and l.split()[3].upper()=='EPSR' for l in original.splitlines() if l and not l.startswith('*') and len(l.split())>3)
lines=[]
for l in original.splitlines():
 if l=='EPSR 42 10 4 10 1.0':continue
 if l.startswith('*') or not l.strip():lines.append(l);continue
 if '42' in l.split():
  assert l=='CDC1 43 42 10U'
  l='CDC1 43 4 10U'
 lines.append(l)
normalized='\n'.join(lines)+'\n'
(ROOT/'ti/lm6172-epsr-alias.lib').write_text(normalized)
(ROOT/'alias-transform.json').write_text(json.dumps(dict(original_sha256=hashlib.sha256((ROOT/'ti/lm6172.lib').read_bytes()).hexdigest(),transformed_sha256=hashlib.sha256(normalized.encode()).hexdigest(),removed='EPSR 42 10 4 10 1.0',replaced=['CDC1 43 42 10U','CDC1 43 4 10U'],reason='Eliminate unobserved unity-source node: V42=V4. No component values changed.'),indent=2))
results=[]
for rails in [12,15]:
 for kind in ['gain1','gain2','inverting']:
  text=amp(kind,rails,model='lm6172-epsr-alias.lib').replace('V(XAMP:42)','V(vcc)')
  results.append(dict(run(f'alias-{kind}-rails{rails}',text),kind=kind,rails=rails))
(ROOT/'alias-results.json').write_text(json.dumps(results,indent=2))
