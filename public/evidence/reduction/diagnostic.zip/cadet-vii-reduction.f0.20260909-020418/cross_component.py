from probe import ROOT,run,amp
import subprocess,json,math
r=[]
for rails in [12,15]:
 for kind in ['gain1','gain2','inverting']:
  name=f'isolated-nominal-{kind}-rails{rails}';prior=ROOT/name/'record.json'
  result=json.loads(prior.read_text()) if prior.exists() else run(name,amp(kind,rails,rel=1e-4,absolute=1e-7))
  r.append(dict(result,simulator='Xyce',kind=kind,rails=rails))
  d=ROOT/f'ngspice-{kind}-rails{rails}';d.mkdir(exist_ok=True)
  if (d/'record.json').exists():
   r.append(json.loads((d/'record.json').read_text()));(ROOT/'cross-component-results.json').write_text(json.dumps(r,indent=2));continue
  s=amp(kind,rails);s='\n'.join(l for l in s.splitlines() if not l.startswith(('.options','.print','.tran','.end')))
  s+='\n.options gmin=1e-16 method=gear reltol=1e-6 abstol=1e-12 vntol=1e-9\n.control\nset wr_singlescale\nset wr_vecnames\nset numdgt=15\ntran .00625n 500n 0 .00625n\nwrdata tran.txt v(source_a) v(output)\nquit\n.endc\n.end\n'
  (d/'circuit.cir').write_text(s);(d/'tran.txt').unlink(missing_ok=True)
  try:
   out=subprocess.run(['ngspice','-n','-D','ngbehavior=ps','-b','circuit.cir'],cwd=d,capture_output=True,text=True,timeout=45);log=out.stdout+out.stderr;(d/'run.log').write_text(log)
  except subprocess.TimeoutExpired as e:
   (d/'run.log').write_bytes((e.stdout or b'')+(e.stderr or b''));record=dict(folder=d.name,simulator='ngspice',kind=kind,rails=rails,status='failed',reason='timeout45s',last_time_ns=None)
   (d/'record.json').write_text(json.dumps(record,indent=2));r.append(record);(ROOT/'cross-component-results.json').write_text(json.dumps(r,indent=2));print(d.name,'timeout',flush=True);continue
  rows=[[float(v) for v in l.split()] for l in (d/'tran.txt').read_text().splitlines()[1:]] if (d/'tran.txt').exists() else []
  checks=dict(exit_success=out.returncode==0,no_error=not any(x in log.lower() for x in ['error','aborted','timestep too small']),endpoint=bool(rows) and abs(rows[-1][0]-500e-9)<1e-18,finite=bool(rows) and all(math.isfinite(v) for row in rows for v in row),monotone=bool(rows) and all(b[0]>a[0] for a,b in zip(rows,rows[1:])))
  record=dict(folder=d.name,simulator='ngspice',kind=kind,rails=rails,checks=checks,status='completed' if all(checks.values()) else 'failed',rows=len(rows),last_time_ns=rows[-1][0]*1e9 if rows else None)
  (d/'record.json').write_text(json.dumps(record,indent=2));r.append(record);print(d.name,record['status'],flush=True)
  (ROOT/'cross-component-results.json').write_text(json.dumps(r,indent=2))
