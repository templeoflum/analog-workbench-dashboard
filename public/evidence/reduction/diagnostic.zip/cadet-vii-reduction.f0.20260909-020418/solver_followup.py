from probe import ROOT,run,amp
import json
cases=[('first-order','.options timeint MAXORD=1'),('nox','.options nonlin-tran NOX=1'),('rhs-tight','.options nonlin-tran RHSTOL=1e-10'),('small-update-off','.options timeint NLSMALLUPDATE=0')]
r=[dict(run('solver-'+n,amp(kind='gain1',extra=o)),options=o) for n,o in cases]
(ROOT/'solver-followup.json').write_text(json.dumps(r,indent=2))
