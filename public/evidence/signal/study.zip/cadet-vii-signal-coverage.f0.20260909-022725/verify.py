from pathlib import Path
import json,numpy as np
ROOT=Path(__file__).resolve().parent
checks=[]
for c in json.loads((ROOT/'comparisons.json').read_text()):
 if c['max_difference_v'] is None:continue
 a,b=[np.loadtxt(ROOT/f/'tran.txt',skiprows=1) for f in c['folders']];t=np.union1d(a[:,0],b[:,0]);v=float(np.max(np.abs(np.interp(t,a[:,0],a[:,2])-np.interp(t,b[:,0],b[:,2]))));assert abs(v-c['max_difference_v'])<1e-14
 checks.append(dict(mode=c['mode'],gain=c['gain'],load_ohms=c['load_ohms'],pair=c['pair'],difference_v=v))
(ROOT/'independent-check.json').write_text(json.dumps(checks,indent=2));print(len(checks),'comparisons independently reproduced')
