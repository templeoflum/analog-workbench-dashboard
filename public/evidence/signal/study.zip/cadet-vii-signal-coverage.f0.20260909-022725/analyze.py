from pathlib import Path
import json,sys,math
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'cadet-vii-reference-stage.f1.20260909-010314'))
from analyze_xyce import difference

def read(r):return [[float(v) for v in l.split()] for l in (ROOT/r['folder']/'tran.txt').read_text().splitlines()[1:]]
def cards(r):return [l.strip() for l in (ROOT/r['folder']/'circuit.cir').read_text().split('.control')[0].splitlines()[1:] if l.strip() and not l.startswith('.options')]
def compress(rows):
 bins={}
 for row in rows:bins.setdefault(min(299,int(row[0]/500e-9*300)),[]).append(row)
 result={rows[0][0]:rows[0][2],rows[-1][0]:rows[-1][2]}
 for b in bins.values():
  for row in [min(b,key=lambda r:r[2]),max(b,key=lambda r:r[2])]:result[row[0]]=row[2]
 return [[t*1e9,v] for t,v in sorted(result.items())]
if __name__=='__main__':
 records=sum([json.loads((ROOT/f'{m}-results.json').read_text()) for m in ['offset_input','offset_thru']],[]);assert len(records)==48
 cases=[];comparisons=[]
 for mode in ['offset_input','offset_thru']:
  for gain in [0,.5,1]:
   for load in [1000,100000]:
    group=[r for r in records if r['mode']==mode and r['gain']==gain and r['load_ohms']==load];table={r['label']:r for r in group};traces={k:read(v) for k,v in table.items() if v['status']=='completed'};results=[]
    for a,b in [('coarse','middle'),('middle','fine'),('fine','tight')]:
     assert cards(table[a])==cards(table[b]);delta=difference(traces[a],traces[b]) if a in traces and b in traces else None
     v=dict(mode=mode,gain=gain,load_ohms=load,pair=[a,b],folders=[table[a]['folder'],table[b]['folder']],max_difference_v=delta);comparisons.append(v);results.append(v)
    deltas=[x['max_difference_v'] for x in results];decreasing=all(v is not None for v in deltas[:2]) and deltas[1]<deltas[0]
    cases.append(dict(mode=mode,gain=gain,load_ohms=load,runs=group,comparisons=results,decreasing=decreasing,points=compress(traces['fine']) if 'fine' in traces else [],initial_output_v=traces['fine'][0][2] if 'fine' in traces else None))
 summary=dict(attempted=48,completed=sum(r['status']=='completed' for r in records),cases=cases)
 (ROOT/'summary.json').write_text(json.dumps(summary,indent=2));(ROOT/'comparisons.json').write_text(json.dumps(comparisons,indent=2));print(summary['completed'],'/48 completed;',sum(c['decreasing'] for c in cases),'/12 decreasing')
 for pair in [('coarse','middle'),('middle','fine'),('fine','tight')]:
  values=[x['max_difference_v'] for x in comparisons if x['pair']==list(pair) and x['max_difference_v'] is not None];print(pair,len(values),max(values) if values else None)
