from runner import ROOT,ng
import sys,json
sys.path.insert(0,str(ROOT.parent/'cadet-vii-reference-stage.f1.20260909-010314'))
from core import core
from check_connections import check_netlist
results=[]
for mode in ['offset_input','offset_thru']:
 for gain in [0,.5,1]:
  text=core(gain,.6,mode);check_netlist(text,.6)
  assert 'XU4 ref 0 ref TL431' in text and sum(l.startswith('X') and l.endswith(' TL074') for l in text.splitlines())==4
  r=ng(f'coupled-reentry-{mode}-g{gain}',text,.003125)
  results.append(dict(r,mode=mode,gain=gain));(ROOT/'coupled-reentry.json').write_text(json.dumps(results,indent=2))
