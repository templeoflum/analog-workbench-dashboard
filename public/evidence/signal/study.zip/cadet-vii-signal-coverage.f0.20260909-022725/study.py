from runner import ROOT,ng
from run_cadet import circuit
import json,sys
mode=sys.argv[1];assert mode in ['offset_input','offset_thru'];records=[]
for gain in [0,.5,1]:
 for load in [1000,100000]:
  for label,step in [('coarse',.0125),('middle',.00625),('fine',.003125),('tight',.003125)]:
   text=circuit(gain=gain,offset=.6,mode=mode,load=load,tight=True).split('.control')[0].replace('.include ti/','.include ../ti/')
   assert sum(l.startswith('X') and l.endswith(' LM6172/NS') for l in text.splitlines())==4
   assert sum(l.startswith('VOFF ') for l in text.splitlines())==1
   name=f'{mode}-g{gain}-load{load}-{label}';r=ng(name,text,step,label=='tight')
   records.append(dict(r,mode=mode,gain=gain,load_ohms=load,label=label,max_step_ns=step));(ROOT/f'{mode}-results.json').write_text(json.dumps(records,indent=2))
