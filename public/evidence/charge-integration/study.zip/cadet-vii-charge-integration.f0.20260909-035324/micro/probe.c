#include "ngspice/ngspice.h"
#include "ngspice/cktdefs.h"
char *errMsg;
int NIcomCof(CKTcircuit*);
int NIintegrate(CKTcircuit*,double*,double*,double,int);
int main(void){
 double hs[]={2.5e-9,3.125e-12,3.125e-14,1e-18,3.90625e-24},ratios[]={1,.5,2};
 puts("h,ratio,kind,q0,q1,q2,a0,a1,a2,legacy,anchored,expected");
 for(int j=0;j<5;j++)for(int r=0;r<3;r++)for(int kind=0;kind<3;kind++){
  CKTcircuit c={0};double states[8][2]={{0}},geq,ceq;double h=hs[j],prev=h*ratios[r],bias=5.04e-8*.0018048324011310513,slope=kind?1e-6:0,acc=kind==2?1000:0;
  c.CKTintegrateMethod=GEAR;c.CKTorder=2;c.CKTdelta=h;c.CKTdeltaOld[0]=h;c.CKTdeltaOld[1]=prev;
  for(int k=0;k<8;k++)c.CKTstates[k]=states[k];
  double ts[]={0,-h,-h-prev};for(int k=0;k<3;k++)states[k][0]=bias+slope*ts[k]+.5*acc*ts[k]*ts[k];
  if(NIcomCof(&c)||NIintegrate(&c,&geq,&ceq,1,0))return 1;
  double anchored=c.CKTag[2]*(states[2][0]-states[1][0])+c.CKTag[0]*(states[0][0]-states[1][0]);
  printf("%.17g,%.17g,%d,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g\n",h,ratios[r],kind,states[0][0],states[1][0],states[2][0],c.CKTag[0],c.CKTag[1],c.CKTag[2],states[0][1],anchored,slope);
 }
 return 0;
}
