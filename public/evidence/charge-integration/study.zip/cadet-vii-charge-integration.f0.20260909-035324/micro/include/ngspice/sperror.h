#define E_ORDER 1
#define E_METHOD 2
#define OK 0
