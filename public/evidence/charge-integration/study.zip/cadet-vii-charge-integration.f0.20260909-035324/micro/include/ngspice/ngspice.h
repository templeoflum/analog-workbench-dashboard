#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TMALLOC(t,n) ((t*)malloc(sizeof(t)*(n)))
extern char *errMsg;
