#define GEAR 2
#define TRAPEZOIDAL 1
typedef struct { int CKTintegrateMethod, CKTorder; double CKTdelta, CKTdeltaOld[8], CKTag[8], CKTxmu; double *CKTstates[8]; } CKTcircuit;
#define CKTstate0 CKTstates[0]
#define CKTstate1 CKTstates[1]
#define CKTstate2 CKTstates[2]
#define CKTstate3 CKTstates[3]
#define CKTstate4 CKTstates[4]
#define CKTstate5 CKTstates[5]
#define CKTstate6 CKTstates[6]
