from pathlib import Path
import subprocess,csv,json
ROOT=Path(__file__).resolve().parent
for tag,source in [('baseline','niinteg.c'),('anchored','niinteg-anchored.c')]:
 exe=ROOT/'micro'/('probe-'+tag)
 subprocess.run(['cc','-O2','-I'+str(ROOT/'micro/include'),str(ROOT/'micro/probe.c'),str(ROOT/'source'/source),str(ROOT/'source/nicomcof.c'),'-o',str(exe)],check=True)
 r=subprocess.run([str(exe)],capture_output=True,text=True,check=True)
 (ROOT/'micro'/('results.csv' if tag=='baseline' else 'anchored.csv')).write_text(r.stdout if tag=='baseline' else r.stdout.replace(',legacy,',',integrated,'))
a=list(csv.DictReader((ROOT/'micro/results.csv').open()));b=list(csv.DictReader((ROOT/'micro/anchored.csv').open()));constant=[(x,y) for x,y in zip(a,b) if x['kind']=='0']
assert len(constant)==15 and all(float(y['integrated'])==0 for x,y in constant)
print('45 evaluations per build; 15 constant histories produce exactly zero current with the candidate.')
