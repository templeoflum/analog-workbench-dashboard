# Charge integration source audit

210 → 211 → 221 · layout positions work → motion builds form → trace audits path

Inspect the exact ngspice 47 release source (SHA verified against installed formula). Build an isolated unmodified baseline before testing any implementation candidate. The diode adds diffusion and depletion charge and sends that total into NIintegrate; Gear currently sums products of history charges and coefficients. Test the numerical cancellation hypothesis with preserved device values and identical circuit decks. Any candidate is diagnostic until compared against baseline, refinement and tolerances. Keep source versions, build configuration and failed results; do not install or replace the system simulator.
