from pathlib import Path
from decimal import Decimal as D,localcontext
import math,json
ROOT=Path(__file__).resolve().parent
r=[]
for v in [-.495,-.1,-.001,-1e-6,-1e-9,-1e-12,0,1e-12,1e-9,1e-6,.000484,.001,.1,.3]:
 vj=.75;c=4.5e-11;m=.302;arg=1-v/vj
 old=vj*c*(1-arg*math.exp(-m*math.log(arg)))/(1-m)
 new=-vj*c*math.expm1((1-m)*math.log1p(-v/vj))/(1-m)
 with localcontext() as ctx:
  ctx.prec=70;dv=D(str(v));dj=D('.75');dc=D('4.5e-11');dm=D('.302');truth=dj*dc*(1-((1-dv/dj).ln()*(1-dm)).exp())/(1-dm)
 r.append(dict(voltage_V=v,reference_charge_C=str(truth),legacy_C=old,stable_C=new,legacy_error_C=str(abs(D.from_float(old)-truth)),stable_error_C=str(abs(D.from_float(new)-truth))))
(ROOT/'depletion-check.json').write_text(json.dumps(r,indent=2));print('14 depletion charge points compared with a 70-digit reference.')
