from pathlib import Path
import json,math
ROOT=Path(__file__).resolve().parent
# Literal scalar loop structure from release NIcomCof, orders 1/2 only.
def coefficients(h,previous,order=2):
 a=[0.]*(order+1);a[1]=-1/h;m=[[0.]*(order+1) for _ in range(order+1)]
 for i in range(order+1):m[0][i]=1.
 acc=0.
 for i in range(1,order+1):
  acc += [h,previous][i-1];arg=1.
  for j in range(1,order+1):arg*=acc/h;m[j][i]=arg
 for i in range(1,order+1):
  for j in range(i+1,order+1):
   m[j][i]/=m[i][i]
   for k in range(i+1,order+1):m[j][k]-=m[j][i]*m[i][k]
 for i in range(1,order+1):
  for j in range(i+1,order+1):a[j]-=m[j][i]*a[i]
 a[order]/=m[order][order]
 for i in range(order-1,-1,-1):
  for j in range(i+1,order+1):a[i]-=m[i][j]*a[j]
  a[i]/=m[i][i]
 return a
r=[];q=5.04e-8*.0018048324011310513
for h in [2.5e-9,3.125e-12,3.125e-14,1e-18,3.90625e-24]:
 for ratio in [1.,.5,2.]:
  a=coefficients(h,h*ratio);legacy=0.
  for i in [2,1,0]:legacy+=a[i]*q
  r.append(dict(step_s=h,previous_to_current=ratio,coefficients=a,constant_charge_C=q,legacy_current_A=legacy,anchored_current_A=sum(a[i]*(q-q) for i in [1,2]),coefficient_sum=math.fsum(a)))
(ROOT/'coefficient-probe.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
