from pathlib import Path
import subprocess,json,math,sys
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'cadet-vii-clamp-feedback.f1.20260909-034035'
def run(tag,exe,source):
 d=ROOT/(tag+'-'+source);d.mkdir(exist_ok=True);text=(OLD/source/'circuit.cir').read_text();(d/'circuit.cir').write_text(text)
 record=dict(tag=tag,source=source,folder=d.name,completed=False)
 try:
  x=subprocess.run([exe,'-n','-D','ngbehavior=ps','-b','circuit.cir'],cwd=d,capture_output=True,text=True,timeout=45);log=x.stdout+x.stderr;(d/'run.log').write_text(log)
  rows=[[float(x) for x in l.split()] for l in (d/'state.txt').read_text().splitlines()[1:]] if (d/'state.txt').exists() else []
  checks=dict(exit_success=x.returncode==0,solver=('Using KLU' if '-klu-' in source else 'Using SPARSE') in log,no_error=not any(t in log.lower() for t in ['error','aborted','singular','timestep too small']),finite=bool(rows) and all(math.isfinite(x) for row in rows for x in row),endpoint=bool(rows) and abs(rows[-1][0]-500e-9)<1e-18,monotone=bool(rows) and all(b[0]>a[0] for a,b in zip(rows,rows[1:])))
  record.update(completed=all(checks.values()),checks=checks,rows=len(rows),last_time_s=rows[-1][0] if rows else None)
 except subprocess.TimeoutExpired as e:
  (d/'run.log').write_bytes((e.stdout or b'')+(e.stderr or b''));record['reason']='timeout45s'
 (d/'record.json').write_text(json.dumps(record,indent=2));print(d.name,record['completed'],record.get('last_time_s'),flush=True);return record
if __name__=='__main__':
 tag,exe=sys.argv[1:];r=[]
 for solver in ['klu','sparse']:
  for step,stimulus in [(2.5,'constant'),(.003125,'constant'),(.003125,'pulse')]:r.append(run(tag,exe,f'clamp-{solver}-{step}-{stimulus}'))
 (ROOT/(tag+'.json')).write_text(json.dumps(r,indent=2))
