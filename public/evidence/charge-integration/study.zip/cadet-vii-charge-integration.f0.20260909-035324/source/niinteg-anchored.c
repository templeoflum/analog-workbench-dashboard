/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
Author: 1985 Thomas L. Quarles
**********/

/* NIintegrate(ckt,geq,ceq,cap,qcap)
 *  integrate the specified capacitor - method and order in the
 *  ckt structure, ccap follows qcap.
 */

#include "ngspice/ngspice.h"
#include "ngspice/cktdefs.h"
#include "ngspice/sperror.h"

#define ccap qcap+1

int
NIintegrate(CKTcircuit *ckt, double *geq, double *ceq, double cap, int qcap)
{
    static char *ordmsg = "Illegal integration order";
    static char *methodmsg = "Unknown integration method";

    switch(ckt->CKTintegrateMethod) {

    case TRAPEZOIDAL:
        switch(ckt->CKTorder) {
        case 1:
            ckt->CKTstate0[ccap] = ckt->CKTag[0] * ckt->CKTstate0[qcap]
                    + ckt->CKTag[1] * ckt->CKTstate1[qcap];
            break;
        case 2:
            ckt->CKTstate0[ccap] = - ckt->CKTstate1[ccap] * ckt->CKTag[1] +
                    ckt->CKTag[0] *
                    ( ckt->CKTstate0[qcap] - ckt->CKTstate1[qcap] );
            break;
        default:
            errMsg = TMALLOC(char, strlen(ordmsg) + 1);
            strcpy(errMsg,ordmsg);
            return(E_ORDER);
        }
        break;
    case GEAR:
        if (ckt->CKTorder < 1 || ckt->CKTorder > 6)
            return(E_ORDER);
        /* Diagnostic candidate: preserve the zero derivative of constant
         * charge by using state1 as the charge origin. The current-charge
         * derivative remains CKTag[0], as used by geq below. */
        ckt->CKTstate0[ccap] = 0;
        for (int i = ckt->CKTorder; i >= 2; --i)
            ckt->CKTstate0[ccap] += ckt->CKTag[i] *
                (ckt->CKTstates[i][qcap] - ckt->CKTstate1[qcap]);
        ckt->CKTstate0[ccap] += ckt->CKTag[0] *
            (ckt->CKTstate0[qcap] - ckt->CKTstate1[qcap]);
        break;

    default:
        errMsg = TMALLOC(char, strlen(methodmsg) + 1);
        strcpy(errMsg,methodmsg);
        return(E_METHOD);
    }
    *ceq = ckt->CKTstate0[ccap] - ckt->CKTag[0] * ckt->CKTstate0[qcap];
    *geq = ckt->CKTag[0] * cap;
    return(OK);
}
