from pathlib import Path
from run_cadet import circuit
import subprocess,json,math,sys
ROOT=Path(__file__).resolve().parent
def run(mode,gain,kind):
 name=f'{mode}-{gain}-{kind}';d=ROOT/name;d.mkdir(exist_ok=True)
 s=circuit(gain=gain,offset=.6,mode=mode,load=100000,tight=True).split('.control')[0].replace('.include ti/','.include ../ti/');s='\n'.join(l for l in s.splitlines() if not l.startswith('.options'))
 s+='\n.options klu method=gear gmin=1e-16 reltol=1e-6 abstol=1e-12 vntol=1e-9\n'
 old='VA source_a 0 DC 0 AC 1 PULSE(0 .2 100n 1n 1n 200n 1u)'
 signals={'pulse':'PWL(0 0 80n 0 90n .16 230n .16 240n .03 520n .03 530n .2 710n .2 720n 0 1u 0)','ramp':'PWL(0 0 100n 0 350n .2 650n 0 900n .12 1u .12)','sine':'SIN(.1 .08 5Meg)'}
 if kind=='ac':analysis='op\nwrdata dc.txt v(output)\nac lin 8193 0 2G\nwrdata ac.txt v(output)'
 else:
  s=s.replace(old,'VA source_a 0 '+signals[kind]);analysis='tran .003125n 1u 0 .003125n\nwrdata tran.txt v(source_a) v(output)'
 s+='\n.control\nset wr_singlescale\nset wr_vecnames\nset numdgt=17\n'+analysis+'\nquit\n.endc\n.end\n';(d/'circuit.cir').write_text(s)
 r=subprocess.run(['ngspice','-n','-D','ngbehavior=ps','-b','circuit.cir'],cwd=d,capture_output=True,text=True,timeout=90);log=r.stdout+r.stderr;(d/'run.log').write_text(log)
 filename='ac.txt' if kind=='ac' else 'tran.txt';rows=[[float(v) for v in l.split()] for l in (d/filename).read_text().splitlines()[1:]] if (d/filename).exists() else []
 ok=r.returncode==0 and bool(rows) and not any(t in log.lower() for t in ['error','aborted','timestep too small']) and all(math.isfinite(v) for row in rows for v in row) and abs(rows[-1][0]-(2e9 if kind=='ac' else 1e-6))<(1e-3 if kind=='ac' else 1e-17)
 record=dict(mode=mode,gain=gain,kind=kind,folder=name,completed=ok,rows=len(rows));(d/'record.json').write_text(json.dumps(record,indent=2));print(name,ok,flush=True);return record
if __name__=='__main__':
 kinds=sys.argv[1:] or ['ac'];r=[]
 for mode in ['offset_input','offset_thru']:
  for gain in [0,.5,1]:
   for kind in kinds:r.append(run(mode,gain,kind))
 (ROOT/('records-'+ '-'.join(kinds)+'.json')).write_text(json.dumps(r,indent=2))
