import fs from 'node:fs';
import {SignalProcessor,patternBlock} from './runtime.mjs';
const root=new URL('.',import.meta.url),model=JSON.parse(fs.readFileSync(new URL('runtime-model.json',root))),results=[];
for(const c of model.cases) for(const kind of ['pulse','ramp','sine','pattern']){
 const path=new URL(`${c.mode}-${c.gain}-${kind}/comparison.csv`,root);if(!fs.existsSync(path))continue;
 const rows=fs.readFileSync(path,'utf8').trim().split('\n').slice(1).map(x=>x.split(',').map(Number));
 for(const chunk of [257,4096]){
 const p=new SignalProcessor(c.kernel,c.dc,rows[0][1]);let peak=0,sq=0,equivalence=0;
 for(let i=0;i<rows.length;i+=chunk){const block=rows.slice(i,i+chunk),out=p.process(Float64Array.from(block,r=>r[1]));
 block.forEach((r,j)=>{const e=out[j]-r[2];peak=Math.max(peak,Math.abs(e));sq+=e*e;equivalence=Math.max(equivalence,Math.abs(out[j]-r[3]));});}
 const rms=Math.sqrt(sq/rows.length),passed=peak<=.001&&rms<=.0001&&equivalence<1e-12;
 results.push({mode:c.mode,gain:c.gain,kind,chunk,peakV:peak,rmsV:rms,pythonDifferenceV:equivalence,passed});
 }
}
const times=[];for(const c of model.cases){const p=new SignalProcessor(c.kernel,c.dc,.1);let previous=.1;for(let i=0;i<100;i++){const start=performance.now(),input=patternBlock(i,4096,previous);previous=input.at(-1);const out=p.process(input);const pixels=new Uint8ClampedArray(4096*4);for(let j=0;j<out.length;j++){const v=Math.round(255*Math.max(0,Math.min(1,(out[j]+.4)/.7)));pixels[j*4]=pixels[j*4+1]=pixels[j*4+2]=v;pixels[j*4+3]=255;}if(i>=10)times.push(performance.now()-start);}}
times.sort((a,b)=>a-b);const report={cases:results,performance:{environment:process.version+' / '+process.platform+' / '+process.arch,scope:'Node filter + pattern + one image packing; excludes browser rendering',samples:times.length,p50ms:times[Math.floor(times.length*.5)],p95ms:times[Math.floor(times.length*.95)]},passed:results.every(r=>r.passed)};
fs.writeFileSync(new URL('runtime-validation.json',root),JSON.stringify(report,null,2));console.log(JSON.stringify({comparisons:results.length,passed:report.passed,peakV:Math.max(...results.map(r=>r.peakV)),rmsV:Math.max(...results.map(r=>r.rmsV)),...report.performance},null,2));if(!report.passed)process.exitCode=1;
