from pathlib import Path
import numpy as np,json
ROOT=Path(__file__).resolve().parent
r=[]
for mode in ['offset_input','offset_thru']:
 for gain in [0,.5,1]:
  d=ROOT/f'{mode}-{gain}-ac';a=np.loadtxt(d/'ac.txt',skiprows=1);dc=float(np.loadtxt(d/'dc.txt',skiprows=1)[1]);H=a[:,1]+1j*a[:,2];h=np.fft.irfft(H,n=16384)
  # Truncation budget fixed independently of held-out signals: 10 uV for a 0.2 V bounded input.
  length=next((n for n in [64,128,256,512,1024] if .2*np.sum(np.abs(h[n:]))<=1e-5),None)
  rec=dict(mode=mode,gain=gain,dc=dc,dcGain=float(H[0].real),kernelLength=length,tailBoundV=float(.2*np.sum(np.abs(h[length:]))) if length else None,kernel=h[:length].tolist() if length else [],totalL1=float(np.sum(abs(h))))
  r.append(rec);print(mode,gain,'length',length,'tail',rec['tailBoundV'],'dc',dc,'gain',H[0])
(ROOT/'runtime-model.json').write_text(json.dumps(dict(sampleNs=.25,derivation='AC inverse transform; no held-out fitting',cases=r),indent=2))
