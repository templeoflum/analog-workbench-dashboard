from pathlib import Path
import numpy as np,json
ROOT=Path(__file__).resolve().parent
model=json.loads((ROOT/'runtime-model.json').read_text());grid=np.arange(4001)*.25e-9;r=[]
for case in model['cases']:
 for kind in ['pulse','ramp','sine']:
  d=ROOT/f"{case['mode']}-{case['gain']}-{kind}"
  if not(d/'record.json').exists():continue
  rec=json.loads((d/'record.json').read_text());assert rec['completed']
  a=np.loadtxt(d/'tran.txt',skiprows=1);u=np.interp(grid,a[:,0],a[:,1]);reference=np.interp(grid,a[:,0],a[:,2]);h=np.array(case['kernel']);initial=u[0]
  predicted=case['dc']+initial*sum(h)+np.convolve(u-initial,h)[:len(u)]
  e=predicted-reference;peak=float(abs(e).max());rms=float(np.sqrt(np.mean(e*e)));r.append(dict(mode=case['mode'],gain=case['gain'],kind=kind,maxErrorV=peak,rmsErrorV=rms,passed=peak<=.001 and rms<=.0001))
  np.savetxt(d/'comparison.csv',np.column_stack((grid,u,reference,predicted,e)),delimiter=',',header='time_s,input_V,reference_V,runtime_V,error_V',comments='')
(ROOT/'validation.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
